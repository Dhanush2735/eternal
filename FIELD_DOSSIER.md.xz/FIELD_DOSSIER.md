# Every field, what it holds

Generated from the packs on disk by `verification/population/alternatives/make_field_dossier.py`. Every count, range and example below is computed from the data; the prose is in `field_notes.py`, and every call-site line is proved against the source by `verify_readers.py`.

**96 fields across 12 levels** — 15,954 place rows · 15,027 events · 51 traits · 16 borders · 6 population regions · 16 census rows · 7 fallback bands · 4 constants · 13 pack files · 1 index · 1 population file · 1 borders file.

| how the field is used | fields |
|---|---|
| used by the game | 74 |
| never even parsed — documentation living inside the data file | 18 |
| parsed, then never consulted | 3 |
| an input key, not a field | 1 |

## place rows — one settlement record — 15,954 of them across the 11 packs that carry sites

### `place.civHint`

The polity the place is attributed to, as free text — 101 distinct values, of which 'india' covers 15,729 rows. It is a hint by name: matching is exact, against the civilizations the packs synthesise.

- **present:** 15,954 of 15,954 rows
- **distinct values:** 101
- **when absent:** the pack id
- **most common:** `india` (15,729), `indus_valley` (14), `egypt_ancient` (11), `mughal` (10), `sumer` (8), `maurya` (7), `british_india` (7), `chola` (6)
- **example:** `kush`
- **read by:** `civilization/HistoryGazetteer.java:530` **parse** — defaults to the pack id; `civilization/CivSynthesis.java:108` **use** — which civilization's traits a place synthesises; `civilization/HistoricalPresence.java:54` **use** — the civ the player is standing in; `civilization/HistoricalPresence.java:112` **use** — matching a place's civ to a known civilization

### `place.confidence`

How well the row is known: estimated (15,727), high (156), medium (71). It is not a score — the engine uses it as a switch (estimated rows skip the hinterland search).

- **present:** 15,954 of 15,954 rows
- **distinct values:** 3
- **when absent:** the string "estimated"
- **every value:** `estimated` (15,727); `high` (156); `medium` (71)
- **example:** `high`
- **read by:** `civilization/HistoryGazetteer.java:499` **parse** — present_only is read from the same key, before it; `civilization/HistoryGazetteer.java:515` **parse** — "estimated" when absent; `civilization/HistoryGazetteer.java:186` **use** — estimated / present-only rows skip the hinterland search

### `place.id`

The place's key: a short lower-case slug. It is what the resolver is asked with, what traits join on, and what the region lookup prefix-matches. No pattern is enforced anywhere, so it is a key by convention only.

- **present:** 15,954 of 15,954 rows
- **distinct values:** 15,129
- **when absent:** the string "site"
- **most common:** `abdullapur_17321_78693` (2), `achampet_17204_78291` (2), `adibhatla_17234_78542` (2), `akhil_pharma_colony_17548_78221` (2), `amdapur_17278_78290` (2), `ameenapur_17524_78324` (2), `ammerguda_17327_78260` (2), `anajpur_17271_78693` (2)
- **example:** `meroe`
- **read by:** `civilization/HistoryGazetteer.java:517` **parse** — the row's key; defaults to "site"; `population/PopulationResolver.java:214` **use** — resolve → findRegion(siteId, lat, lon) — which region answers; `civilization/HistoryGazetteer.java:329` **use** — traitsFor(site.id(), year) — the join key for traits

### `place.lat`

Latitude in decimal degrees. Nominal range -90..90; never range-checked. A row without it is dropped at load, silently.

- **present:** 15,954 of 15,954 rows
- **range:** -20.273 … 41.89 (median 17.79764)
- **distinct values:** 14,746
- **most common:** `18.22828` (4), `18.27807` (4), `18.35456` (4), `18.2725` (4), `17.52383` (3), `17.32747` (3), `17.31851` (3), `17.30185` (3)
- **example:** `16.939`
- **read by:** `civilization/HistoryGazetteer.java:495` **parse** — the loader drops a row that has no lat; `civilization/HistoryGazetteer.java:523` **parse** — into the record; `civilization/HistoryGazetteer.java:171` **use** — nearestOccupied — haversine to the query point; `population/PopulationResolver.java:214` **use** — findRegion — which region covers this point

### `place.lon`

Longitude in decimal degrees, same rule and the same silent drop.

- **present:** 15,954 of 15,954 rows
- **range:** -99.133 … 120.155 (median 78.556355)
- **distinct values:** 14,691
- **most common:** `77.71159` (5), `78.44423` (4), `78.29613` (4), `78.30426` (4), `78.33523` (4), `78.24155` (4), `77.97629` (4), `78.48183` (4)
- **example:** `33.749`
- **read by:** `civilization/HistoryGazetteer.java:495` **parse** — the loader drops a row that has no lon — same guard; `civilization/HistoryGazetteer.java:524` **parse** — into the record; `civilization/HistoryGazetteer.java:171` **use** — nearestOccupied — the same distance; `population/PopulationResolver.java:214` **use** — findRegion — the same lookup

### `place.name`

The display name. Falls back to the id at load when absent. 11,685 distinct names over 15,727 rows, so the same name recurs across packs and countries.

- **present:** 15,727 of 15,954 rows
- **distinct values:** 11,685
- **when absent:** the id
- **most common:** `Lambadi Thanda` (59), `Venkatapur` (43), `Rampur` (35), `Kondapur` (31), `Kothapalle` (31), `Lingapur` (21), `Narsapur` (21), `Laxmipur` (21)
- **example:** `Abdullapur`
- **read by:** `civilization/HistoryGazetteer.java:518` **parse** — falls back to the id; `civilization/HistoryGazetteer.java:78` **use** — displayName() — the id fallback lives here; `civilization/EventNews.java:40` **use** — "This is <name>, year <year>."; `civilization/HistoricalPresence.java:142` **use** — the HUD line the player reads

### `place.note`

One sentence of provenance, median 59 characters — 15,824 of them. It is NOT a component of the Site record: the loader never reads the key, so the game cannot see any of it.

- **present:** 15,824 of 15,954 rows
- **distinct values:** 93
- **when absent:** nothing — the key is not read at all
- **most common:** `OSM named place in Telangana. Start year estimated at load.` (13,287), `OSM named place. occupiedStart filled at load by gravity/diffusion/parent. Not a sourced founding.` (1,841), `Living named place. Start year estimated at load, not a sourced founding.` (599), `OccupiedEnd extended: the named place is still a city; civHint is the historically distinctive polity, not the present government.` (8), `Norte Chico; not Inca. civHint is a placeholder until a pack id exists.` (1), `Pyramid construction window; plateau remains a site after.` (1), `Necropolis of Memphis; Old Kingdom tombs.` (1), `New Kingdom workmen's village.` (1)
- **example:** `Norte Chico; not Inca. civHint is a placeholder until a pack id exists.`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `place.occupiedEnd`

The year the place stops being a place. 9999 on 15,826 of 15,954 rows means 'still there' — a sentinel year sitting where a date belongs.

- **present:** 15,954 of 15,954 rows
- **range:** -2600 … 9999 (median 9999.0)
- **distinct values:** 82
- **when absent:** Integer.MAX_VALUE (still there)
- **most common:** `9999` (15,826), `400` (12), `-1900` (8), `1200` (4), `800` (3), `-1300` (3), `300` (3), `-100` (3)
- **example:** `350`
- **read by:** `civilization/HistoryGazetteer.java:508` **parse** — defaults to Integer.MAX_VALUE when absent; `civilization/HistoryGazetteer.java:75` **use** — occupiedIn — the other end of the window; `civilization/HistoricalPresence.java:145` **use** — the HUD line

### `place.occupiedStart`

The year the place is first attested, as an integer — BCE is negative (-5000..1953 in the data). Absent on 98.6% of rows, and absent means UNKNOWN (Integer.MIN_VALUE inside the engine), never year 0.

- **present:** 227 of 15,954 rows
- **range:** -5000 … 1953 (median 746)
- **distinct values:** 141
- **when absent:** UNKNOWN (Integer.MIN_VALUE) — never year 0
- **most common:** `-300` (13), `-600` (8), `-3000` (7), `-500` (6), `-2600` (6), `800` (5), `1100` (4), `-400` (4)
- **example:** `-750`
- **read by:** `civilization/HistoryGazetteer.java:501` **parse** — optionalInt; absent means UNKNOWN, never year 0; `civilization/HistoryGazetteer.java:75` **use** — occupiedIn(year) — is the place there at all; `civilization/HistoryGazetteer.java:214` **use** — year < occupiedStart + diffusion lag; `civilization/SettlementYearEstimator.java:71` **use** — the weighted estimate of an undated place's start; `civilization/HistoricalPresence.java:144` **use** — the HUD line — "occupied 1200..1500"

### `place.partOf`

The containers the place belongs to: a list of strings, two entries on a few rows. No container is declared anywhere in the data, so any string is legal.

- **present:** 15,727 of 15,954 rows
- **list shape:** 15727 lists, 15,729 members total, 1–2 each, 0 empty
- **distinct values:** 4
- **every value:** `telangana` (13,287); `hyderabad_metro` (1,841); `kamareddy` (599); `ramareddy` (2)
- **example:** `["hyderabad_metro"]`
- **read by:** `civilization/HistoryGazetteer.java:510` **parse** — a list, two containers in places; `civilization/HistoricalPresence.java:152` **use** — the HUD line — partOf=…

### `place.rank`

village | town | city, as a string. 58 rows have none. When present it wins over the urban window, so a row can be a 'city' because it says so and not because of dates.

- **present:** 15,896 of 15,954 rows
- **distinct values:** 3
- **when absent:** null; the urban window decides instead
- **every value:** `village` (15,426); `town` (331); `city` (139)
- **example:** `town`
- **read by:** `civilization/HistoryGazetteer.java:529` **parse** — JSON key "rank" → record field rankOverride; `civilization/HistoryGazetteer.java:91` **use** — rankAt — rank for a year, overriding the urban window; `civilization/HistoricalPresence.java:73` **use** — the rank a presence is spawned at; `population/SettlementDensity.java:73` **use** — npcCap — how many living people the place may hold

### `place.urbanEnd`

The year it stopped being urban. Only meaningful together with urbanStart.

- **present:** 12 of 15,954 rows
- **range:** -1900 … 1687 (median -1900.0)
- **distinct values:** 4
- **explicit nulls:** 2
- **every value:** `-1900` (8); `None` (2); `-500` (1); `1687` (1)
- **example:** `-1900`
- **read by:** `civilization/HistoryGazetteer.java:528` **parse** — the other half of the optional pair; `civilization/HistoryGazetteer.java:98` **use** — rankAt — the same window

### `place.urbanStart`

The year it became urban. Carried by 12 rows, 2 of them as an explicit null; when it and urbanEnd are both real numbers they override rank entirely.

- **present:** 12 of 15,954 rows
- **range:** -2800 … 1518 (median -2600.0)
- **distinct values:** 5
- **explicit nulls:** 2
- **every value:** `-2600` (7); `None` (2); `-2400` (1); `-2800` (1); `1518` (1)
- **example:** `-2600`
- **read by:** `civilization/HistoryGazetteer.java:527` **parse** — optionalInt, null on most rows; `civilization/HistoryGazetteer.java:98` **use** — rankAt — the urban window that makes it a city; `civilization/SettlementYearEstimator.java:58` **use** — deciding whether a place is datable at all

### `place.packId`

(no description)

- **WRITTEN by the loader from the pack id on every place. Unlike the event's, this one IS read: the HUD prints which pack a site came from, and it is the default polity when a row names none.**
- **read by:** `civilization/HistoryGazetteer.java:399` **use** — passed into the Site record when it is built; `civilization/HistoricalPresence.java:140` **use** — the HUD line — which pack this site came from; `civilization/HistoryGazetteer.java:530` **use** — and the default polity when the row names none

### `place.presentOnly`

0. DERIVED: true where the pack is present-only or the row says present_only. It silently changes how confidence and rank are read for the whole pack.

- **DERIVED by the loader — true where the pack is present-only or the row says present_only. It silently changes how every row in the pack is read.**
- **read by:** `civilization/HistoryGazetteer.java:500` **parse** — the pack's present flag, or confidence=present_only; `civilization/HistoryGazetteer.java:186` **use** — present-only rows skip the hinterland search

### `place.radiusKm`

0. DERIVED, not stored: the loader copies the pack's spawnRadiusKm onto every row (30 km historical, 8 km present). It is a spawning radius, not the settlement's area.

- **DERIVED by the loader from the pack's spawnRadiusKm — 30 km historical, 8 km present. It is a SPAWN radius; the Site record's name for it suggests an extent, and it is not one.**
- **read by:** `civilization/HistoryGazetteer.java:172` **use** — km > site.radiusKm() — outside it a place is not "near"

## events — one pinned event with a radius — 15,027 of them

### `event.confidence`

'wikidata' on 14,934 rows, 'high' on 83, absent on 10 — machine-imported rows that look hand-made. Parsed into the record, then never consulted by any line of code.

- **present:** 15,017 of 15,027 rows
- **distinct values:** 2
- **when absent:** the string "high"
- **every value:** `wikidata` (14,934); `high` (83)
- **example:** `high`
- **read by:** `civilization/HistoryGazetteer.java:586` **parse** — "high" when absent

### `event.effect`

What the event does to the place: military_presence (10,423), lockdown (3,143), memorial (1,373), political (61), disruption (17), missing on 10. 'attack' or 'terror' is rewritten to lockdown at load.

- **present:** 15,017 of 15,027 rows
- **distinct values:** 5
- **when absent:** the string "note"
- **every value:** `military_presence` (10,423); `lockdown` (3,143); `memorial` (1,373); `political` (61); `disruption` (17)
- **example:** `disruption`
- **read by:** `civilization/HistoryGazetteer.java:570` **parse** — "note"; "attack"/"terror" is rewritten to lockdown; `civilization/EventNews.java:15` **use** — which rumor sentence is chosen

### `event.end`

The window's closing year, exclusive: activeIn() is year < end. Absent, the loader writes start + 1, so a window is never empty.

- **present:** 14,944 of 15,027 rows
- **range:** -1829 … 2027 (median 1861.0)
- **distinct values:** 1,632
- **when absent:** start + 1
- **most common:** `1945` (291), `2011` (270), `1864` (211), `1865` (193), `2023` (158), `1944` (152), `2015` (149), `1863` (143)
- **example:** `1858`
- **read by:** `civilization/HistoryGazetteer.java:557` **parse** — if absent, start + 1; `civilization/HistoryGazetteer.java:122` **use** — activeIn — the same window

### `event.id`

The event's identity, a slug. Used to suppress a branch — a switched-off event never fires, whatever else the data says.

- **present:** 15,027 of 15,027 rows
- **distinct values:** 15,027
- **when absent:** the string "event"
- **most common:** `fall_constantinople` (1), `sack_baghdad_mongols` (1), `fall_tenochtitlan` (1), `unification_china_qin` (1), `pyramids_giza` (1), `hastings_1066` (1), `ain_jalut_1260` (1), `panipat_1526` (1)
- **example:** `fall_constantinople`
- **read by:** `civilization/HistoryGazetteer.java:577` **parse** — defaults to "event"; `civilization/HistoryGazetteer.java:287` **use** — suppressionFilter — a switched-off event never fires; `civilization/HistoricalPresence.java:186` **use** — the HUD event line

### `event.kind`

What sort of event: battle (8,035), siege (2,404), disaster (2,294), incident (2,222), political (61), military (1), missing on 10. It selects the scene the spawner plays.

- **present:** 15,017 of 15,027 rows
- **distinct values:** 6
- **when absent:** the string "event"
- **every value:** `battle` (8,035); `siege` (2,404); `disaster` (2,294); `incident` (2,222); `political` (61); `military` (1)
- **example:** `battle`
- **read by:** `civilization/HistoryGazetteer.java:584` **parse** — "event" when absent; `civilization/HistoricalPresence.java:190` **use** — the scene line a player reads; `player/PlayerActionDetector.java:188` **use** — hit.event().kind() — which interventions are gated

### `event.lat`

Where it happened, decimal degrees. A pin without lat or lon is skipped entirely.

- **present:** 15,027 of 15,027 rows
- **range:** -58.416 … 73.12 (median 39.29306)
- **distinct values:** 12,377
- **most common:** `51.36667` (18), `41.01224` (16), `50.45` (15), `36.2` (14), `50.85` (14), `50.6` (13), `40.8` (13), `40.63333` (13)
- **example:** `41.008`
- **read by:** `civilization/HistoryGazetteer.java:495` **parse** — a pin without lat is skipped entirely; `civilization/HistoryGazetteer.java:579` **parse** — into the record; `civilization/HistoryGazetteer.java:290` **use** — nearestEvent — haversine to the pin, tested against radiusKm

### `event.lon`

The other half of where.

- **present:** 15,027 of 15,027 rows
- **range:** -179.802 … 179.52 (median 14.42608)
- **distinct values:** 12,822
- **most common:** `6.16667` (19), `28.97602` (16), `2.16667` (16), `14.25` (13), `2.35183` (13), `5.68333` (11), `28.98472` (11), `3.0575` (10)
- **example:** `28.978`
- **read by:** `civilization/HistoryGazetteer.java:495` **parse** — the same guard; `civilization/HistoryGazetteer.java:580` **parse** — into the record; `civilization/HistoryGazetteer.java:305` **use** — nearestEvent — the other half of the distance

### `event.name`

What happened, in words. The loader's fallback when absent is the literal word 'event'.

- **present:** 15,027 of 15,027 rows
- **distinct values:** 13,715
- **when absent:** the string "event"
- **most common:** `Siege of Constantinople` (20), `Siege of Venlo` (18), `Siege of Paris` (13), `Siege of Maastricht` (12), `Siege of Syracuse` (10), `Siege of Belgrade` (9), `Siege of Jerusalem` (9), `Siege of Arles` (9)
- **example:** `Fall of Constantinople`
- **read by:** `civilization/HistoryGazetteer.java:578` **parse** — the fallback is the literal word "event"; `civilization/EventNews.java:14` **use** — the rumor text a villager says

### `event.radiusKm`

How far the event reaches, in km: 20 (8,001), 15 (2,410), 30 (2,255), 8 (2,210), then 65 scattered values. 25 km is the loader's default when absent.

- **present:** 15,017 of 15,027 rows
- **range:** 3 … 40 (median 20)
- **distinct values:** 11
- **when absent:** 25.0 km
- **every value:** `20` (8,001); `15` (2,410); `30` (2,255); `8` (2,210); `12` (65); `25` (55); `10` (9); `40` (4); `6` (4); `5` (2); `3` (2)
- **example:** `12`
- **read by:** `civilization/HistoryGazetteer.java:583` **parse** — 25 km when absent; `civilization/HistoryGazetteer.java:291` **use** — km <= radiusKm — is the point inside the event; `commands/EeOperationalCheck.java:198` **use** — the health check: the 2008 Taj attack must resolve

### `event.start`

The window's opening year, -1830..2026 in the data; 14,944 rows carry it, 83 carry the single-year key instead, and the loader folds that into start. activeIn() is year >= start.

- **present:** 14,944 of 15,027 rows
- **range:** -1830 … 2026 (median 1860.0)
- **distinct values:** 1,630
- **when absent:** no window unless the single-year key is present
- **most common:** `1944` (288), `2010` (270), `1863` (211), `1864` (193), `2022` (161), `1943` (150), `2014` (149), `1862` (143)
- **example:** `1857`
- **read by:** `civilization/HistoryGazetteer.java:556` **parse** — or the single year key, or the row is skipped; `civilization/HistoryGazetteer.java:129` **use** — activeIn(year) — a window is active between its years

### `event.year`

NOT a field of the record: 83 rows carry it and the loader reads it only as an input to start. A single-year event becomes a one-year window.

- **present:** 83 of 15,027 rows
- **range:** -2560 … 2019 (median 1944)
- **distinct values:** 65
- **most common:** `1945` (4), `1947` (4), `2001` (4), `1942` (3), `1944` (3), `1526` (2), `1857` (2), `1916` (2)
- **example:** `1453`
- **read by:** `civilization/HistoryGazetteer.java:555` **input** — read as an INPUT KEY, then folded into start — the record has no year field

### `event.packId`

Which pack the event came from. Written by the loader on every one of the 15,027 events; read by nothing.

- **WRITTEN by the loader from the pack id on every one of the 15,027 events. A record component with no row key behind it, read by nothing.**
- **read by:** `civilization/HistoryGazetteer.java:576` **parse** — written by the loader from the pack id — not a key in the row

## traits — an architecture / invention / introduction attached to places — 51 of them

### `trait.from`

The first year the trait applies. Integer.MIN_VALUE when absent — meaning 'always', which is a different statement from 'from the beginning of time'.

- **present:** 51 of 51 rows
- **range:** -3500 … 1639 (median -1600)
- **distinct values:** 35
- **when absent:** Integer.MIN_VALUE (always)
- **most common:** `-2600` (10), `-3000` (3), `-3200` (2), `-3300` (2), `-2400` (2), `-800` (2), `-2100` (2), `-300` (1)
- **example:** `-300`
- **read by:** `civilization/HistoryGazetteer.java:610` **parse** — Integer.MIN_VALUE when absent; `civilization/HistoryGazetteer.java:137` **use** — activeOn(siteId, year) — the window opens

### `trait.id`

The trait's name. With kind it forms the spawn key ('kind id') that decides whether people here are merchants, artisans or priests.

- **present:** 51 of 51 rows
- **distinct values:** 51
- **when absent:** the string "trait"
- **most common:** `meroe_pyramids` (1), `timbuktu_madrasa` (1), `round_city_baghdad` (1), `olmec_colossal_heads` (1), `maya_pyramid_plaza` (1), `avenue_of_the_dead` (1), `inca_ashlar` (1), `oracle_bone_script` (1)
- **example:** `meroe_pyramids`
- **read by:** `civilization/HistoryGazetteer.java:608` **parse** — defaults to "trait"; `civilization/HistoryGazetteer.java:330` **use** — spawnRoles — the spawn key is "kind id"; `civilization/HistoricalPresence.java:160` **use** — the trait list in the HUD

### `trait.kind`

architecture (32), invention (10), introduction (8), discovery (1). A closed set in practice, open in the file.

- **present:** 51 of 51 rows
- **distinct values:** 4
- **when absent:** an empty string
- **every value:** `architecture` (32); `invention` (10); `introduction` (8); `discovery` (1)
- **example:** `architecture`
- **read by:** `civilization/HistoryGazetteer.java:609` **parse** — "" when absent; `civilization/HistoryGazetteer.java:330` **use** — the other half of the spawn key

### `trait.note`

Prose carried by 5 of the 51 traits. Like the place note, the loader never reads it.

- **present:** 5 of 51 rows
- **distinct values:** 5
- **every value:** `Earlier walls exist; the tourist masonry is mostly Ming.` (1); `Tidal dock interpretation is widely taught; some scholars debate function.` (1); `Script undeciphered. Do not treat as readable laws.` (1); `Mesopotamian texts name Meluhha; majority identify it with the Indus. Not proven 100%.` (1); `Ur-Nammu then Hammurabi; Hammurabi ~1754 BCE is in the kept named-event list.` (1)
- **example:** `Earlier walls exist; the tourist masonry is mostly Ming.`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `trait.sites`

The place ids the trait attaches to — max 5 in the data, and all 51 traits carry the key. An empty list would mean every place, so the join is by bare id with no pack scoping.

- **present:** 51 of 51 rows
- **list shape:** 51 lists, 91 members total, 1–5 each, 0 empty
- **distinct values:** 45
- **most common:** `harappa` (11), `mohenjo_daro` (10), `lothal` (7), `memphis` (5), `rakhigarhi` (4), `ur` (4), `thebes_luxor` (3), `kalibangan` (3)
- **example:** `["meroe"]`
- **read by:** `civilization/HistoryGazetteer.java:603` **parse** — a JSON array of bare place ids; `civilization/HistoryGazetteer.java:140` **use** — activeOn — an empty list means every place

### `trait.until`

The year it stops, exclusive: activeOn is year >= from && year < until.

- **present:** 51 of 51 rows
- **range:** -2181 … 9999 (median -185)
- **distinct values:** 31
- **when absent:** Integer.MAX_VALUE (never ends)
- **most common:** `-1900` (13), `9999` (4), `400` (3), `-1450` (2), `1279` (2), `1687` (2), `350` (1), `1591` (1)
- **example:** `350`
- **read by:** `civilization/HistoryGazetteer.java:611` **parse** — Integer.MAX_VALUE when absent; `civilization/HistoryGazetteer.java:137` **use** — activeOn — the window closes

## borders — a polity's box in space and time — 16, in borders.json

### `border.civId`

The polity's id — the field that makes a border mean something, because it resolves to a civilization the packs can name.

- **present:** 16 of 16 block(s)
- **distinct values:** 16
- **when absent:** the string "neutral"
- **every value:** `maurya` (1); `kushan` (1); `gupta` (1); `satavahana` (1); `rashtrakuta` (1); `delhi_sultanate` (1); `mughal` (1); `maratha` (1); `india` (1); `egypt_ancient` (1); `sumer` (1); `china_han` (1); `rome` (1); `china_qin` (1)
- **example:** `maurya`
- **read by:** `civilization/HistoryGazetteer.java:459` **parse** — "neutral" when absent; `civilization/HistoricalPresence.java:57` **use** — the polity the player is standing in; `civilization/CivSynthesis.java:114` **use** — the list of civilizations the pack cites; `civilization/CivSynthesis.java:248` **use** — matching a border box to a civilization

### `border.end`

The last year it held it, exclusive.

- **present:** 16 of 16 block(s)
- **range:** -1900 … 9999 (median 509.5)
- **distinct values:** 15
- **when absent:** Integer.MAX_VALUE
- **every value:** `220` (2); `-185` (1); `375` (1); `543` (1); `982` (1); `1526` (1); `1857` (1); `1818` (1); `9999` (1); `-30` (1); `-1900` (1); `476` (1); `-206` (1); `1687` (1)
- **example:** `-185`
- **read by:** `civilization/HistoryGazetteer.java:461` **parse** — Integer.MAX_VALUE when absent; `civilization/HistoryGazetteer.java:157` **use** — contains — the same window

### `border.id`

The box's identity, used in the HUD line and in the match line a player sees.

- **present:** 16 of 16 block(s)
- **distinct values:** 16
- **when absent:** the string "border"
- **every value:** `maurya_north_india` (1); `kushan_gandhara_mathura` (1); `gupta_north_india` (1); `satavahana_deccan` (1); `rashtrakuta_deccan` (1); `delhi_sultanate_north` (1); `mughal_north_india` (1); `maratha_west` (1); `india_republic` (1); `egypt_nile` (1); `sumer_alluvium` (1); `han_north_china` (1); `rome_italy` (1); `qin_guanzhong` (1)
- **example:** `maurya_north_india`
- **read by:** `civilization/HistoryGazetteer.java:458` **parse** — defaults to "border"; `civilization/HistoricalPresence.java:123` **use** — the match line: "border <id>"; `civilization/HistoricalPresence.java:181` **use** — the HUD border line

### `border.kind`

The shape of the box: 'box' on all 16. Parsed into the record and then never read — the engine assumes the shape it was given.

- **present:** 16 of 16 block(s)
- **distinct values:** 1
- **when absent:** the string "box"
- **every value:** `box` (16)
- **example:** `box`
- **read by:** `civilization/HistoryGazetteer.java:462` **parse** — "box" when absent

### `border.maxLat`

The northern edge.

- **present:** 16 of 16 block(s)
- **range:** 18.2 … 46.5 (median 32.25)
- **distinct values:** 14
- **when absent:** 90
- **every value:** `32.0` (2); `19.5` (2); `34.5` (1); `36.0` (1); `34.0` (1); `22.0` (1); `35.5` (1); `31.4` (1); `32.5` (1); `41.0` (1); `46.5` (1); `36.5` (1); `18.2` (1); `19.8` (1)
- **example:** `34.5`
- **read by:** `civilization/HistoryGazetteer.java:464` **parse** — 90 when absent; `civilization/HistoryGazetteer.java:160` **use** — contains — the box test; `civilization/CivSynthesis.java:254` **use** — the centre of a civilization's box

### `border.maxLon`

The eastern edge. The four edges are the only real extent of a polity in the data.

- **present:** 16 of 16 block(s)
- **range:** 18.5 … 122.0 (median 80.75)
- **distinct values:** 12
- **when absent:** 180
- **every value:** `88.0` (3); `80.0` (3); `82.0` (1); `79.0` (1); `97.0` (1); `33.2` (1); `47.5` (1); `122.0` (1); `18.5` (1); `111.0` (1); `79.3` (1); `81.5` (1)
- **example:** `88.0`
- **read by:** `civilization/HistoryGazetteer.java:466` **parse** — 180 when absent; `civilization/HistoryGazetteer.java:160` **use** — contains — the box test; `civilization/CivSynthesis.java:255` **use** — the centre of a civilization's box

### `border.minLat`

The southern edge, decimal degrees. With maxLat it is also the centre a synthesised civilization is given.

- **present:** 16 of 16 block(s)
- **range:** 8.0 … 36.5 (median 21.5)
- **distinct values:** 14
- **when absent:** -90
- **every value:** `15.0` (2); `24.0` (2); `21.0` (1); `27.0` (1); `22.0` (1); `20.0` (1); `16.0` (1); `8.0` (1); `30.5` (1); `30.0` (1); `36.5` (1); `32.5` (1); `16.8` (1); `15.5` (1)
- **example:** `21.0`
- **read by:** `civilization/HistoryGazetteer.java:463` **parse** — -90 when absent; `civilization/HistoryGazetteer.java:160` **use** — contains — the box test; `civilization/CivSynthesis.java:254` **use** — the centre of a civilization's box

### `border.minLon`

The western edge.

- **present:** 16 of 16 block(s)
- **range:** 7.0 … 108.0 (median 72.0)
- **distinct values:** 13
- **when absent:** -180
- **every value:** `68.0` (3); `72.0` (2); `70.0` (1); `76.0` (1); `74.0` (1); `72.5` (1); `30.5` (1); `44.5` (1); `108.0` (1); `7.0` (1); `106.0` (1); `77.6` (1); `76.5` (1)
- **example:** `70.0`
- **read by:** `civilization/HistoryGazetteer.java:465` **parse** — -180 when absent; `civilization/HistoryGazetteer.java:160` **use** — contains — the box test; `civilization/CivSynthesis.java:255` **use** — the centre of a civilization's box

### `border.note`

Prose on 6 of the 16 boxes (e.g. which parts of a Mauryan extent are included). Never read by any code.

- **present:** 6 of 16 block(s)
- **distinct values:** 6
- **every value:** `Gangetic + northwest core (includes Haryana). Not the far south.` (1); `Includes Hyderabad. Approximate Deccan core.` (1); `Modern India outline box. Not a detailed border. Pakistan/Bangladesh not included.` (1); `Italy core only, not the whole Mediterranean empire.` (1); `Approximate Golconda sultanate core around Hyderabad. Not a surveyed frontier.` (1); `Approximate Asaf Jahi Hyderabad State core. 1948 Police Action ends it.` (1)
- **example:** `Gangetic + northwest core (includes Haryana). Not the far south.`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `border.rank`

What the ground inside the box is treated as — 'village' on all 16, which is a decision, not an accident: the boxes are quiet ground, not claims to city status.

- **present:** 16 of 16 block(s)
- **distinct values:** 1
- **when absent:** village
- **every value:** `village` (16)
- **example:** `village`
- **read by:** `civilization/HistoryGazetteer.java:453` **parse** — village when absent or unparseable; `civilization/HistoricalPresence.java:84` **use** — the last tier of context before "unknown"

### `border.start`

The first year the polity held the box; contains() is year >= start. Called Integer.MIN_VALUE when absent.

- **present:** 16 of 16 block(s)
- **range:** -3500 … 1947 (median 174.5)
- **distinct values:** 16
- **when absent:** Integer.MIN_VALUE
- **every value:** `-322` (1); `30` (1); `319` (1); `-230` (1); `753` (1); `1206` (1); `1526` (1); `1674` (1); `1947` (1); `-3100` (1); `-3500` (1); `-202` (1); `-300` (1); `-221` (1)
- **example:** `-322`
- **read by:** `civilization/HistoryGazetteer.java:460` **parse** — Integer.MIN_VALUE when absent; `civilization/HistoryGazetteer.java:157` **use** — contains(lat, lon, year) — the year window; `civilization/CivSynthesis.java:252` **use** — the span a civilization is given

## population regions — a place or district with a census series — 6, in the population pack

### `population.endYear`

The first year it no longer applies (1948 for the polity), null when unbounded.

- **present:** 1 of 6 block(s)
- **range:** 1948 … 1948 (median 1948)
- **distinct values:** 1
- **when absent:** null (unbounded)
- **every value:** `1948` (1)
- **example:** `1948`
- **read by:** `population/PopulationResolver.java:675` **parse** — null when absent; `population/PopulationResolver.java:257` **use** — and for years from it onward

### `population.id`

The region's key. The site-id match is a PREFIX test: a place id that starts with the region id qualifies, which is how a place called hyderabad_x can be captured by hyderabad.

- **present:** 6 of 6 block(s)
- **distinct values:** 6
- **when absent:** the string "unknown"
- **every value:** `hyderabad` (1); `secunderabad` (1); `akanpalle` (1); `maheswaram_mandal` (1); `atraf_i_balda` (1); `hyderabad_state` (1)
- **example:** `hyderabad`
- **read by:** `population/PopulationResolver.java:666` **parse** — "unknown" when absent; `population/PopulationResolver.java:289` **use** — findRegion — the site id must START WITH the region id

### `population.kind`

settlement, aggregate or polity — the field that decides everything downstream: only settlements answer a place directly, only aggregates apportion to their settlements, only polities supply a civ-wide floor.

- **present:** 6 of 6 block(s)
- **distinct values:** 3
- **when absent:** the string "settlement"
- **every value:** `settlement` (3); `aggregate` (2); `polity` (1)
- **example:** `settlement`
- **read by:** `population/PopulationResolver.java:668` **parse** — "settlement" when absent; `population/PopulationResolver.java:109` **use** — isSettlement — the rule that decides which regions answer a place; `population/PopulationResolver.java:433` **use** — isAggregate — only aggregates apportion to their villages; `population/PopulationResolver.java:255` **use** — isPolity — only polities supply a civ-wide floor

### `population.lat`

The region's centre, decimal degrees. Used for the distance test; a missing value becomes 0.0/0.0, which is a point in the Atlantic — silently.

- **present:** 6 of 6 block(s)
- **range:** 17.08759 … 17.4399 (median 17.3733)
- **distinct values:** 5
- **when absent:** 0.0 — a point in the Atlantic, silently
- **every value:** `17.385` (2); `17.3616` (1); `17.4399` (1); `17.08759` (1); `17.2394` (1)
- **example:** `17.3616`
- **read by:** `population/PopulationResolver.java:670` **parse** — 0.0 when absent; `population/PopulationResolver.java:290` **use** — findRegion — haversine from the region centre to the point

### `population.lon`

The other half of the centre.

- **present:** 6 of 6 block(s)
- **range:** 78.38949 … 78.4983 (median 78.48085)
- **distinct values:** 5
- **when absent:** 0.0 — the same
- **every value:** `78.487` (2); `78.4747` (1); `78.4983` (1); `78.38949` (1); `78.4331` (1)
- **example:** `78.4747`
- **read by:** `population/PopulationResolver.java:671` **parse** — 0.0 when absent; `population/PopulationResolver.java:290` **use** — the same distance

### `population.name`

The region's display name, falling back to the id. Appears in the provenance text of every interpolated answer.

- **present:** 6 of 6 block(s)
- **distinct values:** 6
- **when absent:** the id
- **every value:** `Hyderabad city` (1); `Secunderabad` (1); `Akanpalle (Akhanpally)` (1); `Maheswaram mandal` (1); `Atraf-i-Balda district (sarf-i-khas)` (1); `Hyderabad State (Asaf Jahi)` (1)
- **example:** `Hyderabad city`
- **read by:** `population/PopulationResolver.java:667` **parse** — falls back to the id; `population/PopulationResolver.java:349` **use** — the interpolated answer names the region and both census years

### `population.radiusKm`

The region's real extent, in km — the only genuine area in the whole project. Hyderabad 8, Secunderabad 6, Akanpalle 3, Maheswaram mandal 20, Atraf-i-Balda 90, Hyderabad State 250.

- **present:** 6 of 6 block(s)
- **range:** 3 … 250 (median 14.0)
- **distinct values:** 6
- **when absent:** 10 km in the resolver's own default, 30 km in the loader's
- **every value:** `8` (1); `6` (1); `3` (1); `20` (1); `90` (1); `250` (1)
- **example:** `8`
- **read by:** `population/ChunkPopulation.java:610` **use** — shareOfPlace — the share of the place inside the view, from its area; `population/ChunkPopulation.java:199` **use** — figuresInChunk — the figures a chunk actually stands up; `population/PopulationResolver.java:205` **use** — radiusKm(siteId, lat, lon) — the place's real extent; `population/PopulationResolver.java:207` **use** — the default when nothing matches — a constant, not a measurement

### `population.rank`

village | town | city: how the region is scaled against a place of another rank (a city is modelled at 2,500x a village).

- **present:** 6 of 6 block(s)
- **distinct values:** 3
- **when absent:** village
- **every value:** `city` (3); `town` (2); `village` (1)
- **example:** `city`
- **read by:** `population/PopulationResolver.java:669` **parse** — village when absent; `population/PopulationResolver.java:417` **use** — gravity — a region of higher rank scales the estimate up; `population/PopulationResolver.java:393` **use** — the winning anchor's rank sets the ratio

### `population.series`

The census rows: a list of {year, population, source}. Sixteen rows carry every population number the game owns.

- **present:** 6 of 6 block(s)
- **list shape:** 6 lists, 16 members total, 1–6 each, 0 empty
- **example:** `[{"year": 1901, "population": 448466, "source": "Census of India 1901, Hyderabad city"}, {"year": 1931, "population": 466894, "source": "Census of India 1931, Hyderaba...`
- **read by:** `population/PopulationResolver.java:347` **use** — logLerp — growth is multiplicative, not additive; `population/PopulationResolver.java:332` **use** — interpolate — only points with a positive number are used; `population/PopulationResolver.java:509` **use** — logLerp itself

### `population.settlementCount`

For an aggregate only: how many settlements the number covers — Maheswaram mandal 33, Atraf-i-Balda 847. The district's total is divided by it; none of the member settlements is stored.

- **present:** 2 of 6 block(s)
- **range:** 33 … 847 (median 440.0)
- **distinct values:** 2
- **when absent:** 0, which disables aggregate apportionment
- **every value:** `33` (1); `847` (1)
- **example:** `33`
- **read by:** `population/PopulationResolver.java:438` **use** — one district's number, divided by its settlements

### `population.startYear`

The first year the region applies, null when unbounded. Only the polity carries it (1724).

- **present:** 1 of 6 block(s)
- **range:** 1724 … 1724 (median 1724)
- **distinct values:** 1
- **when absent:** null (unbounded)
- **every value:** `1724` (1)
- **example:** `1724`
- **read by:** `population/PopulationResolver.java:674` **parse** — null when absent; `population/PopulationResolver.java:256` **use** — a region is skipped entirely for years before it

## census rows — one dated population number with its source sentence — 16 in total

### `series.population`

The count as published, in people. A row of 0 is discarded at load, so a zero is never a statement about the place.

- **present:** 16 of 16 block(s)
- **range:** 1047 … 16338534 (median 434584.0)
- **distinct values:** 16
- **when absent:** 0 — and a zero row is discarded
- **every value:** `448466` (1); `466894` (1); `739159` (1); `1106880` (1); `5742036` (1); `7677018` (1); `135370` (1); `206102` (1); `217910` (1); `1047` (1); `65125` (1); `355787` (1); `389784` (1); `420702` (1)
- **example:** `448466`
- **read by:** `population/PopulationResolver.java:661` **parse** — 0L when absent; a zero row is later discarded; `population/PopulationResolver.java:347` **use** — logLerp between the two bracketing numbers

### `series.source`

The sentence the number came from, verbatim (e.g. 'Census of India 2011, Secunderabad Cantonment Board (22.81 km2, 50,333 households)'). A blank source REJECTS the row at load: an unattributed number is never trusted.

- **present:** 16 of 16 block(s)
- **distinct values:** 16
- **when absent:** an empty string, which REJECTS the whole row
- **every value:** `Census of India 1901, Hyderabad city` (1); `Census of India 1931, Hyderabad city` (1); `Census of India 1941 Vol XXI, H.E.H. The Nizam's Dominions -- Hyderabad city (50.17% Hindu, 46.66% Muslim)` (1); `Census of India 1951, Hyderabad city` (1); `Census of India 2001, Hyderabad urban agglomeration` (1); `Census of India 2011, Hyderabad urban agglomeration` (1); `Census of India 1941, Hyderabad district Secunderabad block: 102,147 Hindu + 21,552 Muslim + 11,671 other` (1); `Census of India 2001, Secunderabad Cantonment Board civil population` (1); `Census of India 2011, Secunderabad Cantonment Board (22.81 km2, 50,333 households)` (1); `Census of India 2011 village code 574779: 546 M / 501 F, 256 households, 33% SC, 30% ST` (1); `Census of India 2011, Maheswaram mandal, Ranga Reddy (33 villages, 14,684 households)` (1); `Imperial Gazetteer of India 1909, Atraf-i-Balda (847 villages incl. jagirs)` (1); `Imperial Gazetteer of India 1909, Atraf-i-Balda` (1); `Imperial Gazetteer of India 1909, Atraf-i-Balda -- 847 villages` (1)
- **example:** `Census of India 1901, Hyderabad city`
- **read by:** `population/PopulationResolver.java:651` **parse** — and a blank source REJECTS the row; `population/PopulationResolver.java:654` **use** — the rejection itself: an unattributed number is never trusted; `population/PopulationResolver.java:222` **use** — the provenance string the player sees

### `series.year`

The census year of the row — the year the number is true, not the year it was published.

- **present:** 16 of 16 block(s)
- **range:** 1881 … 2011 (median 1941.0)
- **distinct values:** 8
- **when absent:** 0
- **every value:** `1941` (4); `2011` (4); `1901` (2); `2001` (2); `1931` (1); `1951` (1); `1881` (1); `1891` (1)
- **example:** `1901`
- **read by:** `population/PopulationResolver.java:660` **parse** — 0 when absent; `population/PopulationResolver.java:339` **use** — interpolate — the bracketing years around the asked year; `population/PopulationResolver.java:308` **use** — exactPoint — an exact year match wins

## fallback bands — an era x rank fallback range — 7, the model's floor

### `band.city`

The same pair for a city — the pair that produced 1,050,000 for Secunderabad in 1840.

- **present:** 7 of 7 block(s)
- **distinct values:** 14
- **every value:** `5000` (1); `30000` (1); `8000` (1); `60000` (1); `10000` (1); `100000` (1); `15000` (1); `150000` (1); `20000` (1); `400000` (1); `40000` (1); `800000` (1); `80000` (1); `5000000` (1)
- **example:** `[5000, 30000]`
- **read by:** `population/PopulationResolver.java:637` **parse** — a two-number array; `population/PopulationResolver.java:117` **use** — min(rank) — the band's lower bound for the rank asked for

### `band.fromYear`

The first year of the era window. Called Integer.MIN_VALUE when absent.

- **present:** 7 of 7 block(s)
- **range:** -3000 … 1900 (median 1000)
- **distinct values:** 7
- **when absent:** Integer.MIN_VALUE
- **every value:** `-3000` (1); `-1000` (1); `0` (1); `1000` (1); `1500` (1); `1800` (1); `1900` (1)
- **example:** `-3000`
- **read by:** `population/PopulationResolver.java:633` **parse** — Integer.MIN_VALUE when absent; `population/PopulationResolver.java:460` **use** — the band's name in the answer the player reads

### `band.toYear`

The last year of the window, exclusive; 9999 renders as 'present'.

- **present:** 7 of 7 block(s)
- **range:** -1000 … 9999 (median 1500)
- **distinct values:** 7
- **when absent:** Integer.MAX_VALUE
- **every value:** `-1000` (1); `0` (1); `1000` (1); `1500` (1); `1800` (1); `1900` (1); `9999` (1)
- **example:** `-1000`
- **read by:** `population/PopulationResolver.java:634` **parse** — Integer.MAX_VALUE when absent; `population/PopulationResolver.java:460` **use** — the same answer line

### `band.town`

The same pair for a town.

- **present:** 7 of 7 block(s)
- **distinct values:** 12
- **every value:** `2000` (2); `3000` (2); `500` (1); `800` (1); `1000` (1); `4000` (1); `1500` (1); `6000` (1); `10000` (1); `20000` (1); `5000` (1); `40000` (1)
- **example:** `[500, 2000]`
- **read by:** `population/PopulationResolver.java:636` **parse** — a two-number array; `population/PopulationResolver.java:455` **use** — the same bounds for a town

### `band.village`

A two-number range [min, max] for a village in this era. The floor tier cannot fail, so these bounds are the difference between a number and zero.

- **present:** 7 of 7 block(s)
- **distinct values:** 12
- **every value:** `150` (2); `200` (2); `40` (1); `50` (1); `60` (1); `250` (1); `80` (1); `300` (1); `100` (1); `400` (1); `700` (1); `1500` (1)
- **example:** `[40, 150]`
- **read by:** `population/PopulationResolver.java:635` **parse** — a two-number array [min, max]; `population/PopulationResolver.java:454` **use** — band.min(rank) / band.max(rank) — the FLOOR pick's bounds

## calibration constants — the model's own constants, in relative units — 4

### `calibration.gravityDecayKm`

The distance constant of the gravity model: weight = 1 / (1 + km/250). Changing it changes every modelled value in the game.

- **present:** 1 of 4 block(s)
- **distinct values:** 1
- **every value:** `250.0` (1)
- **example:** `250.0`
- **read by:** `population/PopulationResolver.java:615` **parse** — 250 km when absent; `population/PopulationResolver.java:392` **use** — decay = 1 / (1 + km / gravityDecayKm) — the pull weakens with distance

### `calibration.gravityRadiusKm`

How far an anchor can still pull: beyond 250 km it is ignored entirely.

- **present:** 1 of 4 block(s)
- **distinct values:** 1
- **every value:** `250.0` (1)
- **example:** `250.0`
- **read by:** `population/PopulationResolver.java:616` **parse** — 250 km when absent; `population/PopulationResolver.java:414` **use** — an anchor beyond the radius does not pull

### `calibration.maxInterpolationGapYears`

The longest gap between two census rows that may be bridged, 60 years. A bigger gap returns no answer rather than a guess.

- **present:** 1 of 4 block(s)
- **distinct values:** 1
- **every value:** `60` (1)
- **example:** `60`
- **read by:** `population/PopulationResolver.java:617` **parse** — 60 years when absent; `population/PopulationResolver.java:345` **use** — a gap wider than this returns no answer rather than a guess; `population/PopulationResolver.java:322` **use** — the same limit for a single nearby point

### `calibration.rankUnits`

Relative weights in units of one village: village 1, town 26, city 2500. They scale a number from one rank to another, and they are a model choice, not a measurement.

- **present:** 1 of 4 block(s)
- **distinct values:** 1
- **every value:** `{"village": 1.0, "town": 26.0, "city": 2500.0}` (1)
- **example:** `{"village": 1.0, "town": 26.0, "city": 2500.0}`
- **read by:** `population/PopulationResolver.java:620` **parse** — the three unit weights; `population/PopulationResolver.java:489` **use** — unitsFor — city 2500, town 26, village 1

## pack files — the block above the rows, in each of the 13 files the index lists

### `pack.comparedSources`

The sources the pack was built from and checked against, as a list of strings. Never read — the pack's provenance stops at the file.

- **present:** 13 of 13 block(s)
- **list shape:** 13 lists, 41 members total, 1–7 each, 0 empty
- **distinct values:** 41
- **most common:** `Wikipedia: Indus Valley Civilisation; Rakhigarhi; Indo-Mesopotamia relations` (1), `Lumen / Boundless world history (Harappan culture, cities)` (1), `ASI / standard site lists (Harappa 1921, Mohenjo-daro 1922, Lothal, Kalibangan, Dholavira, Rakhigarhi)` (1), `Scholarly phase consensus: Early ~3300–2600, Mature ~2600–1900, Late ~1900–1300 BCE` (1), `Standard Mesopotamian chronology (Uruk, ED, Akkad, Ur III, Old Babylonian, Neo-Assyrian)` (1), `Ur / Uruk / Eridu coordinates from site publications / Wikipedia` (1), `British Museum Egypt timeline` (1), `Old Kingdom pyramid chronology (~2686–2181 BCE)` (1)
- **example:** `["Wikipedia: Indus Valley Civilisation; Rakhigarhi; Indo-Mesopotamia relations", "Lumen / Boundless world history (Harappan culture, cities)", "ASI / standard site lis...`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `pack.events`

The array of event pins. 10 of 13 packs carry it.

- **present:** 10 of 13 block(s)
- **list shape:** 10 lists, 15,027 members total, 0–14934 each, 1 empty
- **example:** `[]`
- **read by:** `civilization/HistoryGazetteer.java:543` **use** — the array of event pins

### `pack.id`

The pack's slug — and NOT always the filename: indus.json carries indus_harappan, events.json documents itself as wikidata_events. It becomes every row's packId and the default civHint when a row names none.

- **present:** 13 of 13 block(s)
- **distinct values:** 13
- **when absent:** the string "unknown"
- **every value:** `indus_harappan` (1); `mesopotamia` (1); `egypt` (1); `china` (1); `mediterranean` (1); `south_asia` (1); `americas` (1); `afro_islamic` (1); `present_kamareddy` (1); `present_hyderabad_metro` (1); `present_telangana` (1); `sourced_events` (1); `wikidata_events` (1)
- **example:** `indus_harappan`
- **read by:** `civilization/HistoryGazetteer.java:481` **parse** — "unknown" when absent; becomes every site's packId; `civilization/HistoryGazetteer.java:530` **use** — and the default civHint when a row names none; `civilization/HistoricalPresence.java:140` **use** — the HUD prints the pack a site came from

### `pack.phases`

The pack's named eras: {id, start, end, name, note}, e.g. 'Mature Harappan, -2600..-1900'. 8 of 13 packs carry them and no code reads them — the era knowledge is inert.

- **present:** 8 of 13 block(s)
- **list shape:** 8 lists, 55 members total, 3–17 each, 0 empty
- **example:** `[{"id": "early_harappan", "start": -3300, "end": -2600, "name": "Early Harappan", "note": "Villages and regional centres; not full grid cities everywhere."}, {"id": "m...`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `pack.presentOnly`

true on the three present-day packs: every row in them is treated as present-only, which skips the hinterland search and changes each row's rank handling.

- **present:** 3 of 13 block(s)
- **distinct values:** 1
- **every value:** `True` (3)
- **example:** `true`
- **read by:** `civilization/HistoryGazetteer.java:482` **parse** — makes every row in the pack present-only; `civilization/HistoryGazetteer.java:498` **use** — and present-only rows skip the hinterland search

### `pack.rejected`

What the pack's author deliberately left out (e.g. template events). Documentation, never read.

- **present:** 13 of 13 block(s)
- **list shape:** 13 lists, 32 members total, 1–5 each, 0 empty
- **distinct values:** 31
- **most common:** `Spawning attacker NPCs` (2), `hist_indus_valley_* template events (Golden Dynasty, astrolabe, naval blockade, imperial statutes)` (1), `Template VIPs (Supreme Sovereign / Grand Marshal of IVC)` (1), `vedic_proto as Indus state religion` (1), `Aryan invasion as a proven destruction event` (1), `Exact invention dates (day/year) for weights, drains, cotton` (1), `hist_* Golden Dynasty templates` (1), `one capital for all Sumer` (1)
- **example:** `["hist_indus_valley_* template events (Golden Dynasty, astrolabe, naval blockade, imperial statutes)", "Template VIPs (Supreme Sovereign / Grand Marshal of IVC)", "ved...`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `pack.scope`

One sentence on what the pack deliberately covers (e.g. 'Sites, traits and architecture only. No named kings, wars, or invented yearly events.'). Never read by code.

- **present:** 1 of 13 block(s)
- **distinct values:** 1
- **every value:** `Sites, traits, and architecture only. No named kings, wars, or invented yearly events.` (1)
- **example:** `Sites, traits, and architecture only. No named kings, wars, or invented yearly events.`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `pack.sites`

The array of place rows — the only pack key that produces the game's settlements.

- **present:** 13 of 13 block(s)
- **list shape:** 13 lists, 15,954 members total, 0–13287 each, 2 empty
- **example:** `[{"id": "harappa", "lat": 30.629, "lon": 72.864, "occupiedStart": -3300, "occupiedEnd": -1300, "urbanStart": -2600, "urbanEnd": -1900, "confidence": "high", "civHint":...`
- **read by:** `civilization/HistoryGazetteer.java:486` **use** — the array of place rows

### `pack.spawnRadiusKm`

The spawning radius handed to every row in the pack — 30 km on 11 packs, 8 km on the present ones. The name says spawn; the Site record calls it radiusKm, and two readers have already mistaken it for an area.

- **present:** 11 of 13 block(s)
- **range:** 8 … 30 (median 30)
- **distinct values:** 2
- **when absent:** 30.0 km
- **every value:** `30` (8); `8` (3)
- **example:** `30`
- **read by:** `civilization/HistoryGazetteer.java:483` **use** — becomes every site's radiusKm — a SPAWN radius, not an area; `civilization/HistoryGazetteer.java:172` **use** — km > site.radiusKm() — outside it a place is not "near"

### `pack.title`

A human title for the pack. Never read by code — it is for the person reading the file.

- **present:** 13 of 13 block(s)
- **distinct values:** 13
- **every value:** `Indus / Harappan occupancy pack` (1); `Sumer / Akkad / Babylon / Assyria` (1); `Ancient Egypt` (1); `China (Shang–Qing cores)` (1); `Minoan / Greece / Carthage / Rome` (1); `South Asia after Indus (Maurya–modern cores)` (1); `Olmec / Maya / Teotihuacan / Aztec / Inca` (1); `Nile south, West Africa, caliphates, Ottoman` (1); `Named OSM settlements in Kamareddy: years estimated (gravity/diffusion/parent), not Census 2011 founding` (1); `Named OSM places in Hyderabad–Secunderabad metro; years estimated` (1); `All OSM city/town/village/hamlet in Telangana; years estimated` (1); `Sourced point events (not towns, not attacker spawn)` (1); `Wikidata named events with coordinates and years (−3000 to now). Overlay only. Not towns. Not attacker spawn.` (1)
- **example:** `Indus / Harappan occupancy pack`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `pack.traits`

The array of traits. 8 of 13 packs carry it.

- **present:** 8 of 13 block(s)
- **list shape:** 8 lists, 51 members total, 3–15 each, 0 empty
- **example:** `[{"id": "mud_brick_village", "kind": "architecture", "from": -3300, "until": -1900, "sites": ["harappa", "rakhigarhi", "bhirrana", "kalibangan"]}, {"id": "fired_brick_...`
- **read by:** `civilization/HistoryGazetteer.java:592` **use** — the array of traits

### `pack.unknownOnPurpose`

What is deliberately left unknown — personal names, kings, state religion, dated battles. This is the honesty field, and no code reads it.

- **present:** 10 of 13 block(s)
- **list shape:** 10 lists, 16 members total, 1–6 each, 0 empty
- **distinct values:** 16
- **every value:** `personal names` (1); `kings / emperors` (1); `state religion` (1); `deciphered language` (1); `dated battles` (1); `cause of decline (single event)` (1); `exact Akkad city location` (1); `exact labour methods for Giza` (1); `Xia dynasty as archaeology` (1); `historicity of Romulus` (1); `Maurya/Gupta full borders — not in this pack; Haryana in -250 is not auto-Mauryan without a polygon` (1); `Not every Census town. No Muziris (location debated). No legendary palaces. No pre-−3000 except Indus pack. Other world regions still cores-only.` (1); `Maya political names at every city` (1); `precise Ghana Empire capital location` (1)
- **example:** `["personal names", "kings / emperors", "state religion", "deciphered language", "dated battles", "cause of decline (single event)"]`
- **read by:** nothing — never even parsed — documentation living inside the data file

## the history index — the file that lists the packs and sets the world radii — 1 file

### `index.borders`

The string 'borders.json'. Not read: the loader hardcodes the borders path.

- **present:** 1 of 1 block(s)
- **distinct values:** 1
- **every value:** `borders.json` (1)
- **example:** `borders.json`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `index.estimatedGravityKm`

The world's gravity radius, 250 km. Read and handed to the year estimator.

- **present:** 1 of 1 block(s)
- **range:** 250 … 250 (median 250)
- **distinct values:** 1
- **every value:** `250` (1)
- **example:** `250`
- **read by:** `civilization/HistoryGazetteer.java:365` **parse** — the world's gravity radius, from the index; `civilization/HistoryGazetteer.java:394` **use** — passed into SettlementYearEstimator.estimate

### `index.estimatedHinterlandKm`

The world's hinterland radius, 80 km. Read and used: beyond it, no hinterland estimate is attempted.

- **present:** 1 of 1 block(s)
- **range:** 80 … 80 (median 80)
- **distinct values:** 1
- **every value:** `80` (1)
- **example:** `80`
- **read by:** `civilization/HistoryGazetteer.java:362` **parse** — the world's hinterland radius, from the index; `civilization/HistoryGazetteer.java:210` **use** — km > hinterlandKm — beyond it, no hinterland estimate

### `index.note`

A prose note on the index. Not read.

- **present:** 1 of 1 block(s)
- **distinct values:** 1
- **every value:** `Sourced sites keep their years. Undated named places get estimated occupiedStart (gravity + diffusion lag, else parent kingdom box). Never beginnin...` (1)
- **example:** `Sourced sites keep their years. Undated named places get estimated occupiedStart (gravity + diffusion lag, else parent kingdom box). Never beginning-of-time. Never Cen...`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `index.packs`

The list of pack filenames the gazetteer loads, 13 entries. Read and iterated. Nothing checks that the list matches the directory.

- **present:** 1 of 1 block(s)
- **list shape:** 1 lists, 13 members total, 13–13 each, 0 empty
- **distinct values:** 13
- **every value:** `indus.json` (1); `mesopotamia.json` (1); `egypt.json` (1); `china.json` (1); `mediterranean.json` (1); `south_asia.json` (1); `americas.json` (1); `afro_islamic.json` (1); `present_kamareddy.json` (1); `present_hyderabad_metro.json` (1); `present_telangana.json` (1); `events.json` (1); `events_world.json` (1)
- **example:** `["indus.json", "mesopotamia.json", "egypt.json", "china.json", "mediterranean.json", "south_asia.json", "americas.json", "afro_islamic.json", "present_kamareddy.json",...`
- **read by:** `civilization/HistoryGazetteer.java:368` **parse** — the list of pack filenames to load; `civilization/HistoryGazetteer.java:371` **use** — each entry is compiled into the history path and loaded

### `index.spawnDefaultRadiusKm`

A default spawn radius, 30. Not read by any code.

- **present:** 1 of 1 block(s)
- **range:** 30 … 30 (median 30)
- **distinct values:** 1
- **every value:** `30` (1)
- **example:** `30`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `index.version`

The data-format version of the history index — 2. Read by nothing: the loader does not check it, so a v3 file would load as if it were v2.

- **present:** 1 of 1 block(s)
- **range:** 2 … 2 (median 2)
- **distinct values:** 1
- **every value:** `2` (1)
- **example:** `2`
- **read by:** nothing — never even parsed — documentation living inside the data file

## the population file — the block above the regions in the population pack — 1 file

### `popfile.boundaryCaveat`

The caveat that the regions are approximations, not boundaries — the single most important sentence in the file for anyone quoting a number. Not read by any code, and therefore never shown to a player.

- **present:** 1 of 1 block(s)
- **distinct values:** 1
- **every value:** `City figures change meaning across decades as municipal boundaries grow: Hyderabad 1941 is the city, 2001/2011 are urban agglomeration; Secunderaba...` (1)
- **example:** `City figures change meaning across decades as municipal boundaries grow: Hyderabad 1941 is the city, 2001/2011 are urban agglomeration; Secunderabad 1941 is the 1941 c...`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `popfile.calibration`

The model's constants block: rank units, gravity radius and decay, interpolation gap.

- **present:** 1 of 1 block(s)
- **keys inside it:** `note` (1), `rankUnits` (1), `gravityDecayKm` (1), `maxInterpolationGapYears` (1), `gravityRadiusKm` (1)
- **distinct values:** 5
- **example:** `{"note": "Declared model constants, in relative units where a village = 1. A city is modelled at 2,500x a village, so a 1,000,000 anchor implies roughly 400-person vil...`
- **read by:** `population/PopulationResolver.java:613` **use** — the model's constants are read from here

### `popfile.defaults`

The fallback block: the era x rank bands used when no census row is in range.

- **present:** 1 of 1 block(s)
- **keys inside it:** `note` (1), `bands` (1)
- **distinct values:** 2
- **example:** `{"note": "Era x rank fallback bands. CALIBRATION CONSTANTS, not records. They exist so an occupied place never reports zero. Labelled 'floor'.", "bands": [{"fromYear":...`
- **read by:** `population/PopulationResolver.java:627` **use** — the fallback bands are read from here

### `popfile.id`

The population file's id. Not read by the loader.

- **present:** 1 of 1 block(s)
- **distinct values:** 1
- **every value:** `population_south_asia` (1)
- **example:** `population_south_asia`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `popfile.note`

The file's own note. Not read.

- **present:** 1 of 1 block(s)
- **distinct values:** 1
- **every value:** `SOURCED ROWS ONLY. Every row below is an attributed census or gazetteer figure. Everything the resolver returns that is NOT in this file is derived...` (1)
- **example:** `SOURCED ROWS ONLY. Every row below is an attributed census or gazetteer figure. Everything the resolver returns that is NOT in this file is derived, and is labelled wi...`
- **read by:** nothing — never even parsed — documentation living inside the data file

### `popfile.regions`

The six regions, each with its radius, rank, centre and census series.

- **present:** 1 of 1 block(s)
- **list shape:** 1 lists, 6 members total, 6–6 each, 0 empty
- **example:** `[{"id": "hyderabad", "name": "Hyderabad city", "kind": "settlement", "rank": "city", "lat": 17.3616, "lon": 78.4747, "radiusKm": 8, "series": [{"year": 1901, "populati...`
- **read by:** `population/PopulationResolver.java:644` **use** — the six regions are read and each becomes a Region

### `popfile.title`

The file's title. Not read.

- **present:** 1 of 1 block(s)
- **distinct values:** 1
- **every value:** `Sourced population series, South Asia cores` (1)
- **example:** `Sourced population series, South Asia cores`
- **read by:** nothing — never even parsed — documentation living inside the data file

## the borders file — the block above the 16 borders — 1 file

### `bordersfile.borders`

The array of 16 polity boxes read by the gazetteer.

- **present:** 1 of 1 block(s)
- **list shape:** 1 lists, 16 members total, 16–16 each, 0 empty
- **example:** `[{"id": "maurya_north_india", "civId": "maurya", "start": -322, "end": -185, "kind": "box", "minLat": 21.0, "maxLat": 34.5, "minLon": 70.0, "maxLon": 88.0, "rank": "vi...`
- **read by:** `civilization/HistoryGazetteer.java:444` **use** — the 16 boxes are read and each becomes a Border

### `bordersfile.note`

The file's note: the boxes are approximate cores, not surveyed frontiers. Not read by code.

- **present:** 1 of 1 block(s)
- **distinct values:** 1
- **every value:** `Approximate cores, not surveyed frontiers. Used only when no sourced site is within 30 km. Countryside inside a core spawns as village of that civ.` (1)
- **example:** `Approximate cores, not surveyed frontiers. Used only when no sourced site is within 30 km. Countryside inside a core spawns as village of that civ.`
- **read by:** nothing — never even parsed — documentation living inside the data file
