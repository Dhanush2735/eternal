# Eternal Engine automatic command test report

**Live Minecraft execution: NO.** This sandbox cannot boot Forge 1.20.1.
Every `/ee` leaf was parsed from `EternalEngineCommands.register()` and its Java handler was checked.

| Leaves | Methods | PASS | WARN | FAIL |
|---:|---:|---:|---:|---:|
| 215 | 186 | 215 | 0 | 0 |

## Command roots
`achievements`, `actions`, `affairs`, `agriculture`, `anomaly`, `audio`, `backup`, `blockqueue`, `bot`, `brain`, `building`, `chrono`, `civ`, `class`, `climate`, `codex`, `data`, `debug`, `disaster`, `disease`, `divergence`, `economy`, `ecs`, `event`, `famine`, `help`, `heraldry`, `historian`, `history`, `incident`, `map`, `migration`, `morph`, `npc`, `observer`, `override`, `performance`, `population`, `probe`, `relation`, `religion`, `reload`, `rep`, `reset`, `scan`, `slowdown`, `sovereign`, `speed`, `status`, `tech`, `territory`, `timeline`, `trade`, `urban`, `vehicle`, `villager`, `vip`, `war`, `web`, `year`

## `/ee help` missing roots
`history`

## Results

| # | Command | Handler | OP | Player | Status | Notes |
|---:|---|---|---:|:---:|:---:|---|
| 1 | `/ee status` | `executeStatus` | 0 |  | **PASS** | handler present, feedback path exists |
| 2 | `/ee year` | `executeYear` | 0 |  | **PASS** | handler present, feedback path exists |
| 3 | `/ee year set -500` | `executeYearSet` | 2 |  | **PASS** | OP 2+ |
| 4 | `/ee help` | `executeHelp` | 0 |  | **PASS** | handler present, feedback path exists |
| 5 | `/ee rep` | `executeRep` | 0 | yes | **PASS** | PLAYER required (console will fail) |
| 6 | `/ee rep apply trade` | `executeRepApply` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 7 | `/ee probe` | `executeProbeHere` | 0 | yes | **PASS** | PLAYER required (console will fail) |
| 8 | `/ee probe 0 0` | `executeProbe` | 0 |  | **PASS** | handler present, feedback path exists |
| 9 | `/ee scan chunk` | `executeScanChunk` | 2 | yes | **PASS** | PLAYER required (console will fail); OP 2+ |
| 10 | `/ee scan chunk 4` | `executeScanChunk` | 2 | yes | **PASS** | PLAYER required (console will fail); OP 2+ |
| 11 | `/ee anomaly` | `executeAnomalyProbe` | 0 | yes | **PASS** | PLAYER required (console will fail) |
| 12 | `/ee anomaly probe` | `executeAnomalyProbe` | 0 | yes | **PASS** | PLAYER required (console will fail) |
| 13 | `/ee anomaly chunk` | `executeAnomalyChunk` | 2 | yes | **PASS** | PLAYER required (console will fail); OP 2+ |
| 14 | `/ee anomaly chunk 4` | `executeAnomalyChunk` | 2 | yes | **PASS** | PLAYER required (console will fail); OP 2+ |
| 15 | `/ee affairs` | `executeAffairs` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 16 | `/ee affairs global` | `executeAffairs` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 17 | `/ee affairs war` | `executeAffairs` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 18 | `/ee affairs disease` | `executeAffairs` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 19 | `/ee affairs timeline` | `executeAffairs` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 20 | `/ee affairs debug` | `executeAffairs` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 21 | `/ee incident test` | `executeIncidentTest` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 22 | `/ee vehicle test` | `executeVehicleTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 23 | `/ee brain availability` | `executeBrainAvailability` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 24 | `/ee brain remote-start` | `executeBrainRemoteStart` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 25 | `/ee brain config` | `executeBrainConfig` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 26 | `/ee brain queue` | `executeBrainQueue` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 27 | `/ee brain audit` | `executeBrainAudit` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 28 | `/ee brain test` | `executeBrainTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 29 | `/ee brain affairs-propose` | `executeBrainAffairsPropose` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 30 | `/ee brain anomaly-propose` | `executeBrainAnomalyPropose` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 31 | `/ee web status` | `executeWebStatus` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 32 | `/ee web start` | `executeWebStart` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 33 | `/ee web stop` | `executeWebStop` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 34 | `/ee web url` | `executeWebUrl` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 35 | `/ee bot connect agent_alpha` | `executeBotConnect` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 36 | `/ee bot briefing agent_alpha villager` | `executeBotBriefing` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 37 | `/ee bot proposals agent_alpha` | `executeBotProposals` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 38 | `/ee bot proposal-test agent_alpha trade` | `executeBotProposalTest` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 39 | `/ee blockqueue status` | `executeBlockQueueStatus` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 40 | `/ee blockqueue clear` | `executeBlockQueueClear` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 41 | `/ee building` | `executeBuilding` | 0 |  | **PASS** | handler present, feedback path exists |
| 42 | `/ee building history` | `executeBuildingHistory` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 43 | `/ee building add-test test_colosseum Colosseum` | `executeBuildingAddTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 44 | `/ee building nearby 500` | `executeBuildingNearby` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 45 | `/ee building info test_colosseum` | `executeBuildingInfo` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 46 | `/ee building infer test_colosseum` | `executeBuildingInfer` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 47 | `/ee building damage test_colosseum 25 Siege` | `executeBuildingDamage` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 48 | `/ee building anomalies 500` | `executeBuildingAnomalies` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 49 | `/ee building plan-test test_colosseum TEMPLE` | `executeBuildingPlanTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 50 | `/ee morph status` | `executeMorphStatus` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 51 | `/ee morph jump -500` | `executeMorphJump` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 52 | `/ee morph landmark TEMPLE` | `executeMorphLandmark` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 53 | `/ee morph grammar rome TEMPLE` | `executeMorphGrammar` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 54 | `/ee history -500` | `executeHistory` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 55 | `/ee timeline` | `executeTimeline` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 56 | `/ee timeline branch` | `executeTimelineBranch` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 57 | `/ee timeline divergences` | `executeTimelineDivergences` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 58 | `/ee timeline roll test_event` | `executeTimelineRoll` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 59 | `/ee timeline diverge hist_rome_1_political Siege` | `executeTimelineDiverge` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 60 | `/ee timeline cascade hist_rome_1_political Siege` | `executeTimelineCascade` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 61 | `/ee timeline rift` | `executeTimelineRift` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 62 | `/ee timeline rift hist_rome_1_political` | `executeTimelineRift` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 63 | `/ee timeline rifts` | `executeTimelineRifts` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 64 | `/ee codex` | `executeCodex` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 65 | `/ee codex atlas` | `executeCodex` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 66 | `/ee sovereign court rome` | `executeSovereignCourt` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 67 | `/ee sovereign petition rome grain_subsidy` | `executeSovereignPetition` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 68 | `/ee sovereign treaty rome carthage TEMPLE` | `executeSovereignTreaty` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 69 | `/ee sovereign megaproject TEMPLE` | `executeSovereignMegaproject` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 70 | `/ee sovereign doctrine rome PHALANX` | `executeSovereignDoctrine` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 71 | `/ee sovereign tax rome 15` | `executeSovereignTax` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 72 | `/ee sovereign debase rome` | `executeSovereignDebase` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 73 | `/ee sovereign coup rome Brutus` | `executeSovereignCoup` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 74 | `/ee ecs status` | `executeEcsStatus` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 75 | `/ee ecs populate rome 100` | `executeEcsPopulate` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 76 | `/ee ecs benchmark` | `executeEcsBenchmark` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 77 | `/ee ecs benchmark 100` | `executeEcsBenchmark` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 78 | `/ee ecs flush` | `executeEcsFlush` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 79 | `/ee map sync` | `executeMapSync` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 80 | `/ee audio atmosphere` | `executeAudioAtmosphere` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 81 | `/ee heraldry list` | `executeHeraldryList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 82 | `/ee heraldry give rome` | `executeHeraldryGive` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 83 | `/ee chrono status` | `executeChronoStatus` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 84 | `/ee chrono start` | `executeChronoStart` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 85 | `/ee chrono mode STORY` | `executeChronoMode` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 86 | `/ee chrono phase 2` | `executeChronoPhase` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 87 | `/ee chrono advance` | `executeChronoAdvance` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 88 | `/ee chrono rival` | `executeChronoRivalSpawn` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 89 | `/ee chrono rival spawn` | `executeChronoRivalSpawn` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 90 | `/ee chrono paradox start` | `executeChronoParadoxStart` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 91 | `/ee chrono paradox start 120` | `executeChronoParadoxStart` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 92 | `/ee chrono paradox deliver` | `executeChronoParadoxDeliver` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 93 | `/ee chrono ending TEMPLE` | `executeChronoEnding` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 94 | `/ee event list` | `executeEventList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 95 | `/ee event pending` | `executeEventPending` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 96 | `/ee event info test_colosseum` | `executeEventInfo` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 97 | `/ee event trigger test_colosseum` | `executeEventTrigger` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 98 | `/ee event prevent test_colosseum Siege` | `executeEventPrevent` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 99 | `/ee event load` | `executeEventLoad` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 100 | `/ee data paths` | `executeDataPaths` | 2 |  | **PASS** | OP 2+ |
| 101 | `/ee data install` | `executeDataInstall` | 2 |  | **PASS** | OP 2+ |
| 102 | `/ee data install-overwrite` | `executeDataInstall` | 2 |  | **PASS** | OP 2+ |
| 103 | `/ee data load` | `executeDataLoad` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 104 | `/ee disease list` | `executeDiseaseList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 105 | `/ee disease info outbreak_1` | `executeDiseaseInfo` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 106 | `/ee disease trigger bubonic_plague rome` | `executeDiseaseTrigger` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 107 | `/ee disease quarantine rome` | `executeDiseaseQuarantine` | 2 |  | **PASS** | OP 2+ |
| 108 | `/ee disease cordon rome` | `executeDiseaseCordon` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 109 | `/ee disease doctor-test` | `executeDiseaseDoctorTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 110 | `/ee disease hospital-test` | `executeDiseaseHospitalTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 111 | `/ee disease infect-test` | `executeDiseaseInfectTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 112 | `/ee disease infect-test bubonic_plague` | `executeDiseaseInfectTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 113 | `/ee disease status` | `executeDiseaseStatus` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 114 | `/ee disaster TEMPLE` | `executeDisasterTrigger` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 115 | `/ee war list` | `executeWarList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 116 | `/ee war info war_1` | `executeWarInfo` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 117 | `/ee war declare rome carthage Siege` | `executeWarDeclare` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 118 | `/ee war end war_1` | `executeWarEnd` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 119 | `/ee war army test` | `executeArmyTest` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 120 | `/ee war deploy legio_1` | `executeWarDeploy` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 121 | `/ee war deploy legio_1 SHIELD_WALL` | `executeWarDeploy` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 122 | `/ee war deploy legio_1 SHIELD_WALL 100` | `executeWarDeploy` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 123 | `/ee war battle-test rome carthage` | `executeWarBattleTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 124 | `/ee war siege-test rome carthage` | `executeWarSiegeTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 125 | `/ee war cohorts` | `executeWarCohorts` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 126 | `/ee trade list` | `executeTradeList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 127 | `/ee trade info route_rome_carthage` | `executeTradeInfo` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 128 | `/ee trade open rome carthage overland` | `executeTradeOpen` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 129 | `/ee trade close route_rome_carthage` | `executeTradeClose` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 130 | `/ee trade disrupt route_rome_carthage Siege` | `executeTradeDisrupt` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 131 | `/ee trade caravan route_rome_carthage` | `executeTradeCaravan` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 132 | `/ee trade ambush-test` | `executeTradeAmbushTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 133 | `/ee trade ship-test` | `executeTradeShipTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 134 | `/ee trade logistics` | `executeTradeLogistics` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 135 | `/ee trade prices` | `executeTradePrices` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 136 | `/ee trade prices rome` | `executeTradePrices` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 137 | `/ee economy treasury rome` | `executeEconomyTreasury` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 138 | `/ee economy add rome 5000` | `executeEconomyAdd` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 139 | `/ee economy subtract rome 5000` | `executeEconomySubtract` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 140 | `/ee agriculture food rome` | `executeAgricultureFood` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 141 | `/ee agriculture boost rome` | `executeAgricultureBoost` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 142 | `/ee agriculture climate rome 120` | `executeAgricultureClimate` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 143 | `/ee climate list` | `executeClimateList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 144 | `/ee climate active` | `executeClimateActive` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 145 | `/ee climate region rome` | `executeClimateRegion` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 146 | `/ee climate temp rome 150` | `executeClimateTemp` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 147 | `/ee climate precip rome 150` | `executeClimatePrecip` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 148 | `/ee famine list` | `executeFamineList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 149 | `/ee famine trigger rome` | `executeFamineTrigger` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 150 | `/ee famine end rome` | `executeFamineEnd` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 151 | `/ee population get rome` | `executePopulationGet` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 152 | `/ee population set rome 5000` | `executePopulationSet` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 153 | `/ee migration process` | `executeMigrationProcess` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 154 | `/ee migration list` | `executeMigrationList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 155 | `/ee class tension rome` | `executeClassTension` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 156 | `/ee urban ratio rome` | `executeUrbanRatio` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 157 | `/ee religion list` | `executeReligionList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 158 | `/ee religion convert rome christianity` | `executeReligionConvert` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 159 | `/ee religion holywar rome carthage christianity` | `executeReligionHolyWar` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 160 | `/ee religion excommunicate rome carthage` | `executeReligionExcommunicate` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 161 | `/ee tech list` | `executeTechList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 162 | `/ee tech status rome` | `executeTechStatus` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 163 | `/ee tech unlock rome writing` | `executeTechUnlock` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 164 | `/ee civ list` | `executeCivList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 165 | `/ee civ active` | `executeCivActive` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 166 | `/ee civ info test_colosseum` | `executeCivInfo` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 167 | `/ee civ create test_colosseum Colosseum` | `executeCivCreate` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 168 | `/ee relation score rome carthage` | `executeRelationScore` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 169 | `/ee relation set rome carthage TEMPLE` | `executeRelationSet` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 170 | `/ee territory owner 419000 125000` | `executeTerritoryOwner` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 171 | `/ee territory create-test terr_rome_latium rome` | `executeTerritoryCreateTest` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 172 | `/ee vip list` | `executeVipList` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 173 | `/ee vip info test_colosseum` | `executeVipInfo` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 174 | `/ee vip claim test_colosseum` | `executeVipClaim` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 175 | `/ee vip release` | `executeVipRelease` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 176 | `/ee vip takeover-test test_colosseum DIPLOMATIC` | `executeVipTakeoverTest` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 177 | `/ee vip kill test_colosseum Siege` | `executeVipKill` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 178 | `/ee vip successors test_colosseum` | `executeVipSuccessors` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 179 | `/ee vip tag-self test_colosseum` | `executeVipTagSelf` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 180 | `/ee vip clear-self-tag` | `executeVipClearSelfTag` | 2 | yes | **PASS** | PLAYER required (console will fail); OP 2+ |
| 181 | `/ee villager nearby` | `executeVillagerNearby` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 182 | `/ee villager nearby 64` | `executeVillagerNearby` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 183 | `/ee villager virtual-count` | `executeVillagerVirtualCount` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 184 | `/ee villager explain villager` | `executeVillagerExplain` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 185 | `/ee villager spawn-test rome villager` | `executeVillagerSpawnTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 186 | `/ee villager who` | `executeVillagerWho` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 187 | `/ee villager here` | `executeVillagerHere` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 188 | `/ee villager here villager` | `executeVillagerHere` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 189 | `/ee villager vip-spawn-test caesar` | `executeVillagerVipSpawnTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 190 | `/ee npc nearby` | `executeVillagerNearby` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 191 | `/ee npc nearby 64` | `executeVillagerNearby` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 192 | `/ee npc virtual-count` | `executeVillagerVirtualCount` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 193 | `/ee npc explain villager` | `executeVillagerExplain` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 194 | `/ee npc spawn-test rome villager` | `executeVillagerSpawnTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 195 | `/ee npc who` | `executeVillagerWho` | 0 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail) |
| 196 | `/ee npc here` | `executeVillagerHere` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 197 | `/ee npc here villager` | `executeVillagerHere` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 198 | `/ee npc vip-spawn-test caesar` | `executeVillagerVipSpawnTest` | 2 | yes | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; PLAYER required (console will fail); OP 2+ |
| 199 | `/ee achievements` | `executeAchievements` | 0 | yes | **PASS** | PLAYER required (console will fail) |
| 200 | `/ee actions recent` | `executeActionsRecent` | 0 |  | **PASS** | handler present, feedback path exists |
| 201 | `/ee divergence checks` | `executeDivergenceChecks` | 0 |  | **PASS** | handler present, feedback path exists |
| 202 | `/ee divergence confidence hist_rome_1_political` | `executeDivergenceConfidence` | 0 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard |
| 203 | `/ee divergence mark hist_rome_1_political 95` | `executeDivergenceMark` | 2 |  | **PASS** | OP 2+ |
| 204 | `/ee observer` | `executeObserver` | 0 | yes | **PASS** | PLAYER required (console will fail) |
| 205 | `/ee speed status` | `executeSpeedStatus` | 0 |  | **PASS** | handler present, feedback path exists |
| 206 | `/ee speed vote 10` | `executeSpeedVote` | 0 | yes | **PASS** | PLAYER required (console will fail) |
| 207 | `/ee speed set 10` | `executeSpeedSet` | 2 |  | **PASS** | OP 2+ |
| 208 | `/ee override` | `executeOverride` | 0 |  | **PASS** | handler present, feedback path exists |
| 209 | `/ee slowdown` | `executeSlowdown` | 0 |  | **PASS** | handler present, feedback path exists |
| 210 | `/ee debug core` | `executeDebug` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 211 | `/ee performance` | `executePerformance` | 2 |  | **PASS** | OP 2+ |
| 212 | `/ee reload` | `executeReload` | 2 |  | **PASS** | OP 2+ |
| 213 | `/ee backup` | `executeBackup` | 2 |  | **PASS** | SimulationEngine.getInstance() without isInitialized() guard; OP 2+ |
| 214 | `/ee historian TestPlayer` | `executeHistorian` | 2 |  | **PASS** | OP 2+ |
| 215 | `/ee reset confirm` | `executeReset` | 4 |  | **PASS** | OP 4+ |

## How to run this live on your game

On a running OP 4 client, paste blocks from `EE_COMMAND_TEST_ORDER.md`.
This script is: `python3 test_all_ee_commands.py`
