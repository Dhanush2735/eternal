# Planning session — decisions as they lock

One section per topic. Nothing here is built yet; this is the agreed design, in the order we settled it.

---

## 1. Affairs — the click and the sentence

**The three answers (yours):**

1. **Talk only with an empty hand.** With an item in hand, the item gets used on him and he does not talk.
2. **The subject is the history of the game year** — what has happened in the year the world is
   living in (its wars, outbreaks, incidents, and the event in force at this place that year), told
   in the person's own trade's way. Not a recital of his personal memories; the year is the subject.
3. **Only when clicked.** No unprompted talking, no ambient murmur.

**What is wrong today (measured, not guessed).**

- `HumanNpcEntity.mobInteract` fires on any main-hand click with **no empty-hand test** and returns
  `sidedSuccess`, so the person swallows the click — a lead, bucket or name tag does nothing.
- Every person asks the briefing as `BotAffairsRole.VILLAGER` and then takes
  `category == "event"`, else `facts().get(0)` — and `get(0)` is always the **time** fact. So a quiet
  year makes every mouth in the district say the same sentence: *"The current simulation year is X."*
- `speakToPlayer` reads the person's own role and **never uses it**; `BotAffairsPersonality.focus/prefix`
  (the role lens) has **no caller under villager/ or entity/**.

**The design.**

- **The trade picks the lens.** The role is already on the person; map the project's roles onto the
  seven lenses that exist (soldier, merchant, healer, priest, advisor, historian, villager).
- **The fact is the fact; the sentence is the person.** Voice templates per lens with the year, place
  and subject as slots — the same fact, said the way that trade would say it.
- **Two rules make "no same message" checkable:** the lens picks the category (a soldier never opens
  with the price of grain), and the person picks the fact by a hash of his UUID over his lens's
  eligible facts. Deterministic, no new storage: the same person gives the same line until the year's
  history changes.
- **The year's history, three kinds of fact:** the year itself and the event in force at this place
  (`HistoricalPresence` + `EventNews`), the year's troubles in the region (wars, outbreaks, incidents),
  and the person's standing (civ, place, rank).
- **Knowledge gating:** every fact carries an audience level (common / civic / scholarly / occult) and
  every lens has a ceiling — a farmer may not recite a timeline-branch id or an anomaly scan.
- **Two depths, one conversation:** empty-hand click = a short headline over the head; sneak + empty
  hand = the detailed account in chat (2–5 facts, with years and places). The floating line stays short
  because a line in the air cannot hold a paragraph.

**What will change in the code (four small edits, no new system).**

1. `HumanNpcEntity.mobInteract` — gate on an empty main hand; items fall through to `super`.
2. `HumanNpcEntity.speakToPlayer` — pass the person's own role (mapped) instead of always VILLAGER.
3. The line picker — lens ceiling + UUID-hash choice over the eligible facts; headline and account split.
4. The voice templates — one small table per lens (new file, plain data).

**What it will not do.** No ambient speech, no per-tick work, no new storage, no briefing per person
per tick. Because the click is the only trigger, the existing per-click cost is acceptable — the
digest is *not* needed for speech.

**The honest limit.** "No two people the same" can only be guaranteed while there is more than one
fact for two people to differ on. In a dead-quiet year, two farmers of the same place and the same
trade can still sound alike — the differences then come from the place line and the year, not from
invention. A person never invents a fact to sound different.

**The proof (a plain-Java check, no Minecraft needed).** Feed it 400 identities from the project's own
role pool and a fixed fact set; assert that no two people in a district share their opening line while
the pool allows it, that one person is stable across two clicks, that a new fact changes the line,
that no line rises above its lens's ceiling, and that the headline is short while the account is 2–5
facts.

**Decisions 3 and 4 (yours):**

3. **The news source follows the timeline.** The simulation's own doings (a famine it computed, an
   outbreak it rolled, a war it declared, an incident) may be spoken **only when the player is in an
   alternate timeline**. In the prime world, people repeat **recorded history only** — the events in
   the packs — because in the true timeline the record already says what happened and an invented
   sentence would contradict it.
   - Checkable: `WorldStateManager.getActiveTimelineBranchId()` — default **`"main"`** (prime). A
     branch is any other id; `TimelineBranch.events()` already holds the branch's own
     `AlternativeEvent`s, and the scenario engine already writes them.
   - So the timeline switch is also the switch for living news: **in the true world people are
     historians; in a twisted world they are witnesses.**
   - Honest consequence for this map: near Hyderabad, the world packs hold **3 events within 100 km**
     (2013 blasts, 1687 siege of Golconda, 1458 battle of Devarakonda) and only **4 years of 1 027**
     (1000–2026) have any event at all covering the point. In the prime world, most clicks in most
     years have almost nothing to tell about the year. That is the record, not the code.
4. **The year is held.** A person speaks **the year he was stood up in**, not the live clock year.
   - No new field: he already carries `era = "year_<year>"`, it is written into the replica
     (`tag.putString("Era", …)`) and restored exactly by `VillagerVirtualizer` — so the same person
     tells the same year forever, across leaving and returning.
   - His **body** still follows the live clock (home at night, out by day); his **words** belong to
     his held year. Body = the clock you are in, words = the year he was born into.
   - Consequence: one street can hold people of different years. The line should carry his year, so it
     reads as memory rather than error.

**Still open:** (3) is a short honest quiet-year line allowed — now the common case in the prime
world? (4) strictly this year, or this year plus one line about the place's past?

**One new doubt raised by decision 3:** in the prime world, if the sim's own famine happens but nobody
may speak of it, is that famine real there? My lean: keep computing it — prices, grain and crowds may
react — but an *invented sentence* never enters a mouth in the true timeline. Worth your ruling.

**Decisions 5 and 6 (yours):**

5. **A quiet year shifts the accent: less of the past, more good achievements.** The year's own state gets
   the line; the past recedes; what is *good* and *recent* takes the room.
6. **This year plus one line of the past** — always one, from a real source only.

**What an "achievement" can honestly be built from (checked, this repo):**

| source | what it gives | the gate that keeps it honest |
|---|---|---|
| `TechnologyTree` — 7 entries: Agriculture, Writing, Steel Working, Printing Press, Steam Power, Electricity, Computing | "we have steel, we have power" | only techs the civ has unlocked (`hasUnlocked`) and only those of the **era the year implies** in the prime world |
| `BuildingHistoryDatabase.getBuildingsExistingInYear(year, …)` + `getFamousBuildings()` (cultural significance ≥ 70) | a real building that stands in that year | date must come from a real source; the regional default has **confidence 12** and may not be spoken as fact |
| `SettlementRank` — the packs hold **15 419 villages, 292 towns, 16 cities**; roles follow the rank (farmer → +artisan → +merchant/citizen) | "we're a town now, with artisans" | the rank is the pack's own data |
| `PopulationResolver` growth — Hyderabad **448 466 (1901) → 7 677 018 (2011)** | "my grandfather's time this town was a quarter of this" | the number is the resolver's, spoken as memory, never recomputed in speech |
| `HistoricalLandmarkGenerator` — Parthenon, medieval keep, great pagoda, Colosseum, Gothic cathedral | a landmark the engine can raise | only when it truly exists in the world |
| branch only: sim doings (a war won, a famine ended — `FamineSystem.endFamine`, `DiseaseEngine.endOutbreak`) | "we came through it" | **prime world may not speak them** (decision 3) |

**Open on 5:** whose achievement (the place's / the realm's / his own — today there is *no* personal
record)? Are small goods allowed (a busy market day, a finished building) or only great ones (a tech,
a landmark, a city rank)? And does decision 5 *drop* the one past line in a quiet year (0) or keep it
beside the achievements (1)?

**Decision 7 (yours): affairs are positive *and* negative — both are included.**

- The project already has this idea: `IncidentKind { POSITIVE, NEGATIVE, NEUTRAL }` and
  `IncidentType` = **7 positive** (GOOD_HARVEST, TRADE_BOOM, DISEASE_CONTAINED, POPULAR_REFORM,
  SUPPLY_BREAKTHROUGH, TECH_BREAKTHROUGH, SUCCESSFUL_DIPLOMACY) · **9 negative** (FAMINE, PLAGUE,
  REBELLION, TRADE_ROUTE_RAID, VEHICLE_ACCIDENT, BORDER_SKIRMISH, ECONOMIC_CRASH,
  ASSASSINATION_ATTEMPT, INFRASTRUCTURE_COLLAPSE) · **3 neutral**. Speech uses that polarity; it is
  not invented.
- Checked: the **record is one-sided** — `events_world.json` 14,934 events = battle 7,989, siege 2,398,
  disaster 2,292, incident 2,199, political 56 — **no positive kind at all**. `foundation_events.json`
  (76) is 39 war / 16 political / 5 disaster / 4 disease / 5 scientific / 4 economic / 1 construction.
- Therefore: **every good affair in the game comes from the engine's own state** (harvest, prices,
  incidents of the positive kinds, technology, town rank, growth). If the true world may speak the
  record only, the true world can only ever be bad news — which decision 7 rules out.
- **Open fork (the one to settle):** in the **true** world, may a person speak the *living state* of
  the world (this year's harvest, prices, sickness, an incident that happened) as well as the record?
  Working reading: **yes** — living state is speakable everywhere; what is **branch-only** is the
  *rewritten* history (a war the sim declares that the record says did not happen, a divergence),
  because only that contradicts the record.
- Polarity belongs to the fact **and the trade**: a price rise is bad for a labourer and good for a
  merchant holding stock. Each affair carries the fact plus the lens's view of it; the fact stays one
  fact.

**Decision 8 (yours, and it settles the fork): it is a history simulation — the record only in the
true world; as it is lived only in an alternate timeline.**

Operational line between the two, so the rule cannot drift:

- **The record** = the shipped data: the 13 event files (**15,027** events), the climate record
  (Little Ice Age 1300-1850, Year Without a Summer 1816), census rows, borders, and a place's identity
  - and only **up to the person's held year**: a man of 1901 cannot tell you 1947.
- **As it is lived** = anything the running simulation computes: incidents it rolls, wars it declares,
  outbreaks, famines, caravans, **technology unlocks** (checked: `TechnologyEngine.tick` unlocks by
  `calculateResearchSpeed(civId, state)`, *not* by the year - so "we have steel" is not record),
  modelled population, reputation, divergences, anomalies.

Consequences that follow, not chosen but forced:

1. The record is **military and natural**: battle 8,035 / siege 2,404 / disaster 2,294 / incident 2,222
   / political 61. Its few positives are **political turnings** (Bastille 1789, Armistice 1918,
   Independence and Partition 1947, Fall of Saigon 1975, Berlin Wall 1989) - good or bad depends on
   whose mouth, so polarity still lives in the trade.
2. The seven POSITIVE incident kinds are **branch-only** content in practice: they are rolled by the
   sim, not written in the record.
3. **Tech unlocks and modelled population may not be spoken in the true world**; a **census row may**,
   because a census is a written record (Hyderabad 448 466 in 1901 is speakable; a modelled village
   average is not).
4. The place packs are **present-only** (`presentOnly: true`, 15,727 sites, `occupiedEnd 9999`), so a
   man of 1901 may not say "we are a town" - that is a 2026 record. Place *identity* (there is a place
   here, this is its name) is usable; its present-day rank is not.
5. In the true world a **quiet year is the normal year**; the one past line now carries the record's
   whole weight, which is exactly what the record is for.

**Decision 9 (mine, on your "your choice"):** reach **100 km**; **up to two** record facts for the year
(one nearest, one greatest by kind weight x radiusKm); **exactly one** past line, always. Reasons from
the data: Hyderabad holds **5 events within 100 km** across all years (**7 years of 1,027** have any),
Paris holds **138, up to 14 in one year** - so one radius works only with a capped, significance-picked
slots. The whole affairs contract is written out in **`AFFAIRS_CONTRACT.md`** (11 sections, one page).

## 2. Civilization — the three points, and what the code actually does

**Your points:** (1) boy and girl names are being mixed, and civilization names too; (2) there should be
a boy skin and a girl skin of every civilization; (3) more history, achievements, etc.

**Found, by reading the source (all counts reproduced by script):**

1. **Male job titles on women.** Every built-in pool has a female list (**11 pools, all OK** — deccan
   27 male / **21 female**, indic 19 / 15, …), and the living spawn path does pass the gender. But
   `rolesTitles` has **no gender dimension**: the title is the male occupational word, so a woman is
   named **"Sipahi Fatima Khan"**, **"Ryot Lakshmamma Reddy"**. That is one of the two mixings seen.
2. **A Rajput and a West African empire get Chinese names.** `cultureFor` matches substrings anywhere
   in the id: **`chandela` → east_asian** because "han" sits inside "*handela*", and
   **`songhai_empire` → east_asian** because "song" sits inside "*song*hai". Two ids, both plainly wrong;
   all other substring matches (shahi→shah, byzantium→byzant, cheras→chera) are benign.
3. **Colonial ids take the Deccan pool.** `british_india` and `french_india` match "india" first →
   deccan names (a British officer named Ramaiah Reddy).
4. **Ground with no site/border gives the id `present` (or `ohm`), which resolves to the global pool
   `["Alex", "Sam"]`** — an Indian villager named *Alex Sam*. `HistoricalPresence.spawnCivId()` returns
   `"present"` / `"ohm"` on those paths.
5. **The crowd has no identity at all.** `CrowdFigures.stand` sets only `setUUID(...)` — **no civ, no
   role, no era, no gender, no name**. So: the skin comes from `SkinVariety` (UUID → one of the 9 game
   skins, **gender-blind and civ-blind**), and clicking a crowd figure runs the fallback line
   *"Greetings, traveler. I am Citizen, serving the null."*
6. **No civilization has its own skin today.** `textures/entity/human/` is **empty (0 files)**, so
   `SkinMatrixRegistry`'s per-civ path `textures/entity/human/<civ>/<era>_<role>.png` never fires for
   anybody; everyone wears one of Minecraft's nine defaults.

**The fixes (planning):** (a) token-boundary matching in `cultureFor` + a colonial pool + `present`/`ohm`
resolved to the nearest site's civ (never the global pool); (b) gendered titles — female forms, or no
title where none exists; (c) the crowd gets the same identity a living person gets — civ from the place,
**gender derived from the figure's own identity hash** (deterministic, so the same figure is always the
same person, no storage), and a name from the pool when clicked; (d) a **civ × gender → ordered list of
the nine skins** table as data, with per-civ art winning when a texture pack supplies it.

**More history / achievements:** the honest sources — extend the existing Wikidata pull (its own query
is recorded in the packs: battle, siege, disaster, incident, political with P625 and P585/P580) to
**positive kinds and establishments**; curate a regional pack (Hyderabad today: **5 events within
100 km**, **7 years of 1 027** with anything); and **source founding years for the 15 727 sites**
(today `occupiedStart` is modelled at load and `occupiedEnd` is 9999 everywhere) — which also feeds the
affairs contract's "one line of the past".

**Open:** art budget for per-civ skins; whether the gender reading of the 9 default skins is our own
data; female title forms; automatic pulls vs a curated regional pack; whether a crowd figure ever shows
a name.

**Skins — answer to "can you use the same approach as names?", and to "more detailing":**

Yes, and it was built as a prototype and then detailed from the official files.

- `verification/population/alternatives/skins_preview.py` — v1: a pool per culture x gender, a pick by
  identity, painted straight to a 64x64 PNG with no library and no Minecraft.
- `verification/population/alternatives/skins_v2.py` — v2, built after **downloading the official
  steve.png / alex.png** (kept in `alternatives/reference/`) and measuring them pixel by pixel. Rules
  and sources: `alternatives/skin_reference_notes.md`.
- Sheets: `skin_method_2d.png` (v1) and **`skins_detailed_2d.png`** (v2, 24 figures: culture x gender x
  trade, plus the official Steve head beside one of ours on the same grid).
- v2 adds: brows, eyes on row 4 with the white on the outer pixel (as the official file does), nose row,
  mouth, three beard depths, long hair for women, sleeve with a darker cuff, trousers and shoes, a belt,
  a collar necklace for women, per-face edge shading and a per-identity weave, and on the **second
  layer** the trade's garment (tabard, vest, stole, apron, robe), the trade's mark (strap, pouch, beads,
  cross) and headgear (wrap turbans with a brow band, caps, veils falling beside the face, an iron
  helmet).
- Machine-checked on every run: the base layer is **1632 of 1632 mapped pixels opaque** (Java forces the
  inner layer opaque; Steve paints 1664 of 4096), the same identity is **byte-identical**, a different
  identity is a different person, and a texture is ~3 KB (Steve is 847 bytes, a JPG is impossible).
- Also learned, and it matters: of Minecraft's nine default skins, **Ari/Kai/Steve/Sunny/Zuri are
  wide-armed and Alex/Efe/Makena/Noor slim** - and the NPC renderer builds the **wide** model, so four of
  the nine were never a clean fit. One more reason to paint our own rather than re-sort the nine.

**Open on skins:** the palettes are our own data (need the user's eye, or real references per culture);
era is not yet a dimension; where the painting happens (ship PNGs vs paint in Java at startup).

**Skin research (male/female properties) — done, and it found a real bug in the mod.**

- Sources and what they say: `alternatives/skin_reference_notes.md` (gendered section). In short: the
  **model is the strongest cue** (4-px arms male, 3-px arms female); masculine shading is angular,
  feminine is rounded with an hourglass; feminine eyes are the **2x2 type with lashes on the hat layer**
  that bend round the side of the head; blush, jewellery and longer hair follow.
- Applied in `alternatives/skins_v3.py`; sheet **`skins_gender_2d.png`** (4 culture pairs, each with the
  code's own call-outs, the four heads on a pixel grid, and the hat layer shown beside them).
- **The find:** `client/HumanNpcRenderer.java:24` builds the model with
  `new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false)` - **false = not slim** - so every
  person in the world wears the **wide** model. The game ships `ModelLayers.PLAYER_SLIM`, and
  `HumanNpcEntity.DATA_GENDER` is already synced to the client. So the strongest male/female cue is
  switched off for the whole population; the fix is two models in the renderer chosen by `getGender()`.
  Measured from the official files: alex.png's arm texture is not a mirror of steve.png's, so the slim
  model needs its own 3-px arm regions.
- Checks printed by v3: arms 4/3 px, lashes on the female's hat layer and none on the male's, female
  jewellery present, base layer fully opaque, same identity byte-identical.

**Skins v4 — hair pool, clothing by era, all eleven cultures (`alternatives/skins_v4.py`,
`skins_world_2d.png`).**

- **Hair is now a pool**, per culture and gender, picked by identity: female styles
  plait_over / bun / loose / wrapped (scarf) / braid / bob; male short / short_beard / turban_wrap /
  long / curly.
- **Clothing by era uses the project's own bands** - `eraForYear` in
  `anomaly/BuildingAnomalyDetector.java:104` (and again in `BuildingDateInferenceEngine.java:71`):
  MODERN >= 1945, INDUSTRIAL >= 1750, RENAISSANCE >= 1450, MEDIEVAL >= 500, ANCIENT below - read
  against the person's held year (`era = "year_<year>"`, task 27). The era changes what is **visible
  at 16x32**: sleeve length (4, 2 or 0 rows), how much leg is covered (bare / wrapped / trousers),
  tunic vs coat on the second layer, footwear (sandal / shoe / boot) and the hat. Verified against the
  project's own mapping by assertion.
- **First attempt was wrong and was rebuilt**: it only shifted the dye by 4%, which is invisible on the
  sheet. The lesson is recorded: an era must change the silhouette, not the shade.
- **All eleven culture groups** the name database already has (deccan, indic, maurya, persianate,
  mesopotamian, mediterranean, rome, north_african, african, east_asian, americas) - five more are
  added to the painter (african, americas, east_asian, north_african, rome, maurya), so culture is
  resolved once for names and faces alike. Panel C shows all 11 at one year, both genders.
- **Composition fixed**: a trade's vest on the second layer was hiding the era's coat. Now the **era
  decides the garment** and the **trade re-adds its mark** (strap, pouch, beads, cross) on top.

**Skins — "all places, all years, male and female" answered by generating the whole set.**

- **The insight: a skin is a function, not a table.** It follows from culture (11 groups), gender (2),
  era (5 bands, from the project's own `eraForYear`), trade (12 roles) and identity. *Place and year
  add nothing:* all **15,727** places in the local packs resolve to the same culture (`civHint: india`
  → deccan), and all 5,100 years collapse into 5 bands.
- **The complete set was written to disk**: `alternatives/skin_set/` — **1,320 files, 1.94 MB total,
  1,539 bytes each**, every culture x gender x era x trade. Script: `make_skin_coverage.py`; sheet with
  the full matrix and the twelve trades: **`skins_coverage_2d.png`**.
- **The cost comparison, stated honestly:** per place per year = 160,415,400 skins ≈ **136 GB**;
  per place = 31,454 ≈ 27 MB (24x more than needed, and every village repeats the same faces); the
  whole world this way = **1.94 MB**; this map alone = **120 skins ≈ 240 KB**.
- How 1,320 skins become a population: the pool supplies the variant, the identity picks it and
  jitters tone/cloth/weave, so two Deccan farmers of one era are the same pool and different people —
  and the man met in 1901 is the man met again, because his number never changes.
- **Bug this exposed:** all 15,727 Telangana places say `civHint: india` - one name pool for the whole
  province. The fix is the same method as names: **place-level variants** (a Telugu pool, a Deccani
  Urdu pool, a Marathi pool, a Kannada pool, and a forest/tribal pool) chosen by the place's own
  identity, so two villages thirty kilometres apart are not the same faces.

**Skins v5 — the EVOLUTION, not five costumes (`alternatives/skins_v5.py`, `skins_evolution_2d.png`).**

- **What v4 got wrong:** it dressed a person from **five fixed bands** — a man of 1200 and a man of 1440
  wore literally the same clothes and then jumped at the boundary; and **hair never moved with the
  year** (a woman of 300 BCE and one of 1970 could wear the same plait). Five bands are a *step*, not an
  evolution.
- **What v5 does:** twelve turning points per place (`PROFILE`) generate six **curves over years**, read
  at any year. Four features are **continuous** - rows of arm covered, rows of leg covered, length of
  the outer garment, strength of the women's drape - and three **step** because a place changes them
  over a generation: the foot (sandal → shoe → boot, colonial + 1790), the head, the hair.
- **Each place has its own dates**, which is the whole point of an evolution: East Asia's robe is gone in
  one year, **1912**; the Americas' dress is replaced at the conquest, **1520**; Africa's colonial break
  is late (**1900**) and print cloth brings the wrap back **1965**; the Persianate and North African
  drape **rises again after 1979**; the Indic drape never falls (0.90 of 1.0 at 2025).
- **Hair is a history, not a pool:** `HAIR_HISTORY` gives each style an arrival year, and a style never
  leaves the pool, because some people keep the old fashion. So the older the year, the fewer the
  styles; the newest is dominant. Checked: the pool grows with the year in **22 of 22** place-and-gender
  pairs.
- **"All years" is a small set, not 5,100 sets.** Walking every year from 3000 BCE to 2025 and quantising
  the features to what the eye can see: **936 distinct outfits for the whole world**, both genders,
  5,100 years - **1.28 MB** as files (15.4 MB if all twelve trades are baked in per outfit).
- **Three of my own bugs, found by looking rather than trusting the checks:** (1) footwear was drawn
  from an **interpolated** curve, so a man of AD 200 wore shoes - fixed by making the foot a step;
  (2) the year's headwear **erased the hair** - fixed by drawing the hair last, over the clothes;
  (3) `HAIR_LENGTH` was computed and **never applied**, so East Asia's 1912 queue-cut was invisible in
  the pixels - fixed with a `draw_hair` that takes the year's length.

**Skins v6 — the modern wardrobe, item by item (`alternatives/skins_v6.py`,
`make_modern_sheet.py`, `skins_modern_2d.png`).**

- **Why:** the user rejected v5's modern age - it dressed everyone in one generic shirt and one pair of
  trousers. They supplied the reference list (crew-neck tee, graphic tee, polo, button-down overshirt,
  mock turtleneck, hoodie, sweatshirt, knitted cardigan, trench, bomber, shacket, blazer, puffer vest,
  jeans, straight trousers, cargo, joggers, tailored shorts, chunky sneakers, Chelsea boots, crossbody
  bag, baseball cap; and for women crop top, tank, camisole, V-neck tee, oversized button-down, ribbed
  cardigan, sheath dress, slip dress, trench, oversized blazer, cropped puffer, wide-leg and mom jeans,
  pleated trousers, midi slip skirt, biker shorts, platform loafers, dad sneakers, shoulder bag, bucket
  hat).
- **Every garment in that list is drawn** - 22 men's and 20 women's - and each carries the year it
  arrives, so the wardrobe grows the way the hairstyles do: **2 men's garments in 1900, 10 in 1950, 22
  in 2025**; and the trade still shows (a soldier and a priest of one year differ in 963 pixels).
- **The load-bearing bug this exposed:** v5's `standee` blitted only five layers and **left out the
  trouser layer and the sleeve layer** - i.e. every coat's skirt and sleeves drawn under `jacket` were
  invisible on every sheet so far. The v6 standee blits the full vanilla stack.
- **Other real bugs found while looking, not by trusting checks:** the shacket's collar was painted on
  the **body** layer, burying the tee underneath; trouser hems were drawn in rows 10-11, which are the
  **shoe** area of the skin, so the shoes painted over them; row 9 of the torso was **bare skin** under
  every top (the waistband covers only 10-11 in a vanilla skin); and two garments of one part drew the
  same colour, so they read as one garment - the palette is now salted with the garment's name, which
  took the closest pair from 12 to 276 pixels.
- Checks: each garment against v5's generic look (smallest change 968 px) · every garment against every
  other **within its part** (closest pair 276 px; shoe-vs-shoe and jean-vs-jean are the honest floors at
  16x32) · the wardrobe grows with the year · the trade still shows · one identity byte-identical.
- **Not sourced:** the arrival years are plausible, one number each, the user's call. Two pairs are
  admitted as near-identical at this size in the sheet's own notes.

**The bindi — "remove bindi for modern clothing" (done).**

- **What it was:** one pixel, colour **(168, 32, 44)**, at `head_front + (3, 2)` - the brow - painted by
  `v3.jewels` for the cultures whose `female_jewels` string contains "bindi": **deccan, indic, maurya**.
  The nose stud is a different pixel and a different question; it was left alone and said so.
- **The rule:** `skins_v6.BINDI_GOES_WITH_MODERN_TOP = True` - a woman keeps the bindi while she is in
  her era's dress and loses it the moment a modern top or dress is on her. `skins_v5` drops it from the
  MODERN band on, for every culture that has it, so the evolution sheet and the wardrobe sheet agree.
  `skins_v3.jewels(..., bindi=True)` is the new flag, defaulting on, so every earlier sheet is unchanged.
- **How it was verified:** by the pixel that carries it. Deccan, Indic and Mauryan women: bindi at 1200,
  bindi at 1900 (no modern garment yet), and **no bindi at 2025**; Persianate women, who never had one,
  are byte-identical before and after the change. The sheet carries a panel with the mark printed on the
  cheek of each figure's caption, so the claim is visible and not just asserted.
- **A second, worse bug this uncovered:** with the modern wardrobe treated as a *replacement*, a woman of
  1900 - who has no modern garment yet - was painted **bare**, and men of 1900-1930 lost the era's own
  cloth. The wardrobe is now a **layer over the era's dress**: a part that has no modern garment this
  year keeps the historical one, and the check holds it pixel-identical to `skins_v5` for those years.

**The bindi, resolved for good (`skins_v6.py`, `make_modern_sheet.py`).**

- **What the user meant, after the second time:** the bindi is not to be worn with modern clothing, for
  any woman, anywhere. Not "wherever a modern top happens to be drawn" - the modern figure has no bindi.
- **The rule as it now stands:** `v6.paint` passes `bindi=not chosen` - the mark is off whenever the
  **modern wardrobe dresses that figure**, every culture, every year, every garment. A year the modern
  wardrobe has not reached yet (a woman of 1900) is still in her era's dress, and the mark belongs to it;
  that case is check 8's, pixel-identical to `skins_v5`. The evolution sheet (`skins_v5`) drops the mark
  from the MODERN band on, so the two sheets agree; the historical sheet keeps it before 1945.
- **Verified two ways, by the pixel that carries it:** **297 modern figures** (11 cultures x 4 years x 7
  garments) - bindi found on **0**; and the historical dress still wears it - **3 of 3** cultures show it
  at 1200. The sheet's panel prints the brow pixel beside each figure, so the claim is visible.
- **A file I destroyed and rebuilt:** a bad `open(p,'w')` self-read truncated `skins_v6.py` to zero bytes.
  It was rebuilt from the patches in this session and re-verified by the same 8 checks; the sheet script
  was untouched throughout.
- **Checks 7 and 8 were made to agree, not to pass:** 7 tests only figures the modern wardrobe dresses,
  8 owns the "no modern garment yet" case. The earlier disagreement was the checks catching a real
  inconsistency in my own rule, which is what they are for.

**The skin pool — the names pattern applied to faces and clothes (`alternatives/skin_pools.py`,
`skins_pool_2d.png`). Awaited: the user's approval before any Java.**

- **The pattern copied, field for field:** names keep `firstNamesMale / firstNamesFemale / surnames /
  rolesTitles{role}` per region, loaded world-pack -> jar -> code defaults, resolved
  **own region -> culture group -> generic**, drawn once at spawn, stored on the entity. The skin pool is
  the same shape: **tones, hairs, cloths, hairStylesMale/Female, garments{role}, uniforms{role}, and the
  era's twelve turning points** (`lower`, `femaleJewels` too), with the same three levels of loading.
- **The user's rule, which changed the design:** *"change of clothes everyday for every npc except who
  has uniforms"*. So the **face** (tone, hair colour, hair style) is a function of the person's UUID and
  **never changes**, while the **clothes** are a function of the UUID **and the day**. `soldier`, `guard`
  and `priest` wear the same cloth every day - a uniform that changes daily is not a uniform.
- **The daily-clothes leak my own check caught:** the palette was salted with the day for everyone, so
  soldiers changed colour every day. Fixed by giving a uniform its own cloth, from the trade, not from
  the person's palette and not from the day.
- **Uniforms are now real garments** in the painter (`g_uniform`: tunic and trousers in one cloth; khaki,
  field green, or a priest's vestment), a part of their own ("suit") which suppresses the top and the
  bottom under it.
- **Findings against the real corpus (103 civ ids):** `chandela` -> indic (it matched "han") and
  `songhai_empire` -> african (it matched "song"); and **three Deccan sultanates — adil_shahi,
  imad_shahi, nizam_shahi — fell through to `global`** in the Java rule, now caught by "shahi". After the
  fix: **103 of 103 resolve to a real pool, none to `global`**, spread deccan 17 · indic 53 ·
  mediterranean 6 · east_asian 6 · african 5 · americas 5 · persianate 4 · mesopotamian 3 ·
  north_african 2 · maurya 1 · rome 1.
- **The cultural garments are declared, not drawn yet:** kameez, lungi, angavastram, sari, kurta, dhoti.
  They are named in the pools and deliberately kept out of the modern garment lists until they are drawn,
  or the `garments` field would lie.
- Checks: 103/103 resolve · the two wrong ids fixed · the face identical on six days · the clothes changed
  on all six · soldier, guard and priest identical on all six · a citizen of the same culture NOT
  identical · same person and same day byte-identical · no garment typo.

**"Did you implement for each and every place?" — the honest answer was no. Now yes
(`alternatives/skin_places.py`, `skins_places_2d.png`, `alternatives/place_pools.tsv`).**

- **The honest answer:** one pool per **culture**, and all **15,727** local places cite `india` →
  `deccan` → one pool. So the forest hamlet and the Hyderabad merchant shared the same names, tones and
  cloth. Every place had a pool in the sense that every place *resolved* to one; no place had its own.
- **The lever that makes it possible:** every place carries **lat/lon** - 15,954 of them, all with
  coordinates, and they are **~1.05 km apart** (median nearest neighbour) across a **451 x 422 km** box,
  plus 227 world sites. So the pool can be a **function of position** instead of 15,954 hand-written
  lists.
- **The three levels, in the spirit of own-region → culture → generic:**
  1. **culture** - from the place's civ, through the same `cultureFor` rule as the names (103/103 resolve)
  2. **sub-pool** - the nearest sub-pool centre, in kilometres. The Deccan's five: **telugu, deccani,
     marathi, kannada, forest**, with centres at Warangal, Hyderabad, Nanded, Raichur and Adilabad.
     Other cultures have two to four each; **34 sub-pools in all**.
  3. **flavour** - the place's own ground quantised to a ~5 km cell (`0.05 deg`), so neighbours share its
     faces and a place thirty kilometres away does not.
- **Measured, not asserted:** a place's ten nearest neighbours share its sub-pool **99%** of the time;
  **153 of 200** places share their flavour cell with their nearest neighbour; **0 of 200** pairs ~30 km
  apart share one. Hyderabad draws tone (191,137,93); the forest east draws (110,68,37).
- **The division, place by place:** telugu 3,770 · deccani 6,764 · marathi 2,742 · kannada 819 ·
  forest 1,632. The map on the sheet is every place at its true coordinates.
- **Written out as data:** `place_pools.tsv`, **15,954 rows** (place, lat, lon, civHint, culture, subpool,
  flavour, pack) - so the table can be checked without redrawing anything.
- **The honest limit:** the five centres and their tones are **plausible, not sourced**. What is verified
  is coverage, neighbour agreement, and the 30 km difference.

---

# The skin system, as implemented (the Java)

The pool the user approved was Python sheets. This is the same pool inside the game, and the checks that
say so.

## The files

| file | what it is | seen by |
|---|---|---|
| `skin/SkinHashes.java` | BLAKE2b-64, written out by hand so the Java draws the Python's world | the rig, 7/7 vectors |
| `skin/SkinPoolDatabase.java` | the pool: 12 cultures (11 + the generic fallback), the wardrobe with arrival years, the per-part 70/30 draw, the three load levels | the rig |
| `skin/SkinPlaceResolver.java` | culture -> sub-pool (34 centres) -> ~5 km flavour cell, from lat/lon | the rig |
| `skin/SkinPainter.java` | the 64x64: face, hair, era dress from twelve turning points, the modern wardrobe, uniforms, the bindi rule | the rig |
| `skin/SkinPng.java` | a 64x64 PNG written by hand (IHDR/IDAT/IEND), so no pixel-layout guess reaches the screen | the rig, decoded and compared |
| `skin/SkinManager.java` | the game's four calls: place, face, outfit, paint; the texture key is a function of the picture, not the person | the rig |
| `skin/SkinSelfTest.java` | 12 groups of checks, 31 assertions | the rig |
| `client/SkinTextures.java` | the bridge: paints, encodes, registers a DynamicTexture, caps the cache at 1024 | **uncompiled here** |
| `client/HumanNpcRenderer.java` | one changed method: the pool first, the shipped-texture registry second | **uncompiled here** |
| `data/FoundationDataLoader.java` | one added line: `SkinManager.boot(EternalDataPaths.root(server))`, beside the name pools | **uncompiled here** |
| `resources/.../names/skin_pool.json` | the pack: 11 cultures, 20,153 bytes, written from `skin_pools.py` POOLS by `make_skin_pack.py` | the rig, check 10 |

## What the rig proves (31 assertions, all green)

1. **The hash is the Python's.** Seven vectors, including `""` and `"india"`. Without this every face
   would differ from the sheets and nothing else would mean anything.
2. **101 civ ids from the packs resolve**, none to the generic pool; the strays the names rule got wrong
   (`chandela` -> indic, `songhai_empire` -> african) and the three `*_shahi` -> deccan are pinned.
3. **A face never changes**: six people, identical across calls; same person and same day, byte-identical.
4. **Clothes change daily**: citizen, farmer and merchant changed 6 times in 6 day-steps; soldier, guard
   and priest wear one cloth on all seven days, pixel-identical.
5. **Two people are two people**: a stranger differs in ~885 of 4096 pixels.
6. **The year bites**: deccan 1200 vs 2025, 1146 px; east Asia 1900 vs 2025, 1130 px; and 1950 vs 2025
   inside the modern age, 110 px - the wardrobe really does grow with the year.
7. **A crowd**: 400 people at Hyderabad -> 72 faces, 1732 pictures over a week of days, 27,712 KB
   uncompressed, and the census is deterministic.
8. **The wardrobe table is the Python's**: 1900 2/0, 1930 8/1, 1950 10/1, 1970 16/6, 1990 20/12,
   2010 22/19, 2025 22/20 - seven rows, exact.
9. **The bindi**: 40 modern-dressed women, 0 marks; 40 historically-dressed women, 40 marks.
10. **Pack and code are one pool**: 11 cultures, every field identical; and the loader reads both
    spellings of a shape curve (1.00 -> 100, 0.55 -> 55, 100 -> 100).
11. **The PNG round-trips**: the JDK's own image reader decodes the Java's PNG with all 4096 pixels
    equal to the painter's memory.
12. **The Java's own output**, 192 skins, drawn into `skins_java_2d.png`.

Run it with `bash verification/population/run_skins.sh /path/to/jdk17`. The rig never compiles the
`villager/` tree; the three rows marked *uncompiled here* are the first things the user's Gradle sees.

## Two things the first run caught, both real

* **The hash was byte-reversed.** The Python reads its eight digest bytes big-endian; assembling them
  little-endian gave a different world. The self-test printed both numbers side by side.
* **The loader zeroed every shape curve.** The pack carries fractions (1.00, 0.85) and the code whole
  percentages; reading them as ints truncated them to 0, which would have dressed the whole world in
  plain European cloth. `turningPoint()` now reads both spellings.

## Still the user's call

* **The palette** - tones, hairs, cloths and the twelve turning points per culture. Labelled plausible,
  not sourced, and editable in one file (`skin_pool.json`), which now provably equals the code's copy.
* **The woman's model.** The pool paints a woman's hair, lashes and clothes, but a skin only looks female
  from the front if the model is the slim (3-pixel) one. `HumanNpcRenderer` presently uses the wide model
  for everyone; a second renderer instance for women is the vanilla-shaped way to do it.
* **Crowd fillers.** The figures that stand share 40 drawn variants; the NPCs that live each carry their
  own face. If the fillers should also wear pool faces, that is a spawner decision, not a painter one.

---

# Topic 3 (open): more history — the web research

Every number below is a **live probe of 2026-10-07** against our own box (15.5-20.5N, 76-82E). Nothing
here is read off a project's blurb. Files: `alternatives/history_sources.tsv` (measures + licences),
`alternatives/history_probe_cliopatria.tsv` (town × year table), sheet `history_sources_2d.png`.

## Why the record is thin — measured

15,027 events exist, of which 14,934 are the world file, and its own header says its source: Wikidata
CC0, nine classes, items with coordinates and dates. In **our box** that is:

* **15 events**, none before 1310 (three Sieges of Warangal, Devarakonda, Talikota, Bidar, Golconda,
  Wagingera, Condore, Masulipatam, Adoni, then 1948/1993/2013);
* kinds: battle 7,989 · siege 2,398 · disaster 2,292 · incident 2,199 · political 56 — **no temple
  built, no canal dug, no famine, no founding, no scholar**. A crowd stands in 15,727 places and the
  record knows 15 things about the whole province.

## What the sources actually hold for this box

| source | licence | measured in our box | adds |
|---|---|---|---|
| Wikidata events | CC0 | **6** events with coords+dates | already in |
| Wikidata dated works (P571) | CC0 | **773** items: college 61, university 60, engineering school 56, academic institution 39, district 38, school 31, hospital 31 | built and institutional record |
| OpenHistoricalMap | CC0 | **532** dated features: 383 administrative relations, 139 ways, 10 nodes; 47 polity names (British Empire 240, Company Raj 25, British Raj 15, Mughal 11, Maratha 7, Hyderabad State 6, Vijayanagara, Golconda, Bidar, Berar, Ahmadnagar…) | dated borders and features, incl. the sultanates |
| Cliopatria v0.2.1 | CC-BY-4.0 | **58 of 64** town-year cells for Hyderabad, Warangal, Nanded, Adilabad | who ruled the place, every year, 3400 BCE-2024 |
| Imperial Gazetteer 1909 | public domain | 349-page Hyderabad State volume; district and town entries with 1901 census, crops, trades | town-level fact for our places |
| Siddham inscriptions | CC-BY-SA-4.0 | Sanskrit/Prakrit/Telugu/Kannada/Persian corpus, early BCE to 19th c. | the pre-1000 depth: dated grants, temple and land records |
| Famine reports | public domain | Greenough: 4 famines before 1000 CE, 24 in 1000-1499, 18 in the 16th c, 27 in the 17th, 18 in the 18th, 30 in the 19th | the disaster class, with regions and years |
| Seshat databank | CC-BY-NC-SA | polity-level variables, 30 world regions | **non-commercial — careful** |
| World Historical Gazetteer | mixed | 2.7M records; curation CC-BY-NC-4.0, datasets CC-BY-4.0, sources each their own | **licence fragmentation — careful** |

## The Cliopatria line for our own towns

Hyderabad: Satavahana → Chalukya → W. Chalukya → Kakatiya (1200, 1323) → Bahmani → Golconda (1565,
1650) → *gap 1687* → Hyderabad State → British Empire → British Raj → Republic. Warangal agrees until
1687, where it becomes Mughal while Hyderabad is a gap. Nanded goes Yadava → Bahadur/Bidar → Bijapur →
Mughal → *gap 1750* → Maratha → British. Adilabad goes Yadava → Berar → Mughal (from 1565 — **60 years
earlier than Warangal's Mughal**). The neighbours differ because the borders really did move through
the province — which is the whole point of the project.

## The plan shape (nothing built)

* **Stage 1 — who ruled you** (cheap, adds the most): Cliopatria polities per year at each place, as
  pack rows. Budget 1 : 1 : 2 with (a) Wikidata dated works in the box, (b) OHM dated borders. No new
  machinery — the existing pack loader carries 15,027 rows and would carry these.
* **Stage 2 — what happened here** (the literature): Imperial Gazetteer town entries (public domain) 1:1
  with the record; Siddham inscriptions as dated events; Famine Commission lists with regions.
* **Stage 3 — depth before 1000** (the red half of panel D): 45 Wikidata items for 2,000 years.
  Inscriptions are the only route, and they give grant dates, temple endowments, land records.

## New fields this asks for

`actor` (who), `cause` (why), `outcome` (what changed) on the event record. The existing shape is
`id, name, start, end, lat, lon, kind, effect, radiusKm, confidence` — it can hold a date but not a
sentence, and the talk system needs sentences.

## Caveats found in the probe (for the importer, not the user)

* one Wikidata item in the box carries a **2800s** date — anything that reads P571 needs a sanity window;
* OHM's box is colonial-heavy (British Empire 240 of 383 relations) — its ancient side is thin;
* Cliopatria ships **border uncertainty as a stated property**, and 6 of 64 cells are gaps, i.e. "known
  unknown", not "no rulers";
* Seshat's NC licence and WHG's fragmentation mean those two cannot be treated like the CC0/CC-BY ones.

### Topic 3 build result (rulers, 2026-10-07)

The ruler record is built: 274 timelines over 15,741 places, 600 BCE - 2024 CE, from Cliopatria
v0.2.1 (CC-BY-4.0). Rule: smallest plain polity covering the place that year; the 522 relation
rows are facts, not rulers. Earliest name in the province: Janapada of Asmaka, 600 BCE, 149
places; everything else starts at the Maurya polygon, 291 BCE. Median coverage 2,189 of 5,026
years; 1,119 gaps left visibly blank. 209 of 213 world sites mapped. Sheet `rulers_span_2d.png`,
pack `history_deep/deccan_rulers.json` (2.4 MB) + engine-shape `rulers_pack.json` (37.6 MB,
generated, not wired). Details: `history_deep/RULERS_BUILD.md`.

### Topic 3 build result 2 (events, 2026-10-07)

Second layer collected: 103 dated events, 1150-1905, read from the Imperial Gazetteer of India,
Hyderabad State (1909), public domain. Every event carries actor, cause, outcome and the volume's
own sentence as a quote (103/103 anchor-resolved by `resolve_events.py`). Kinds are mapped onto
the engine's vocabulary (political 63, battle 27, memorial 10, disaster 3). Cross-check against
the ruler record: median 5 years between the book's date and the nearest change of ruler in the
polygon data; neither layer is adjusted to the other. Sheets: `history_events_2d.png` (events) and
`rulers_span_2d.png` (rulers). Build details: `history_deep/RULERS_BUILD.md`.

Note: the ruler layer's files were dropped once by the workspace snapshot (only the sheet
survived); it was rebuilt from source with `build_rulers_v2.py` and re-verified. Next candidate
sources for the pre-1000 story layer: Siddham inscriptions (CC-BY-SA) and the famine reports.

### Topic 3 build result 3 (pre-1000 + the rest of the volume, 2026-10-07)

Third collection. **Siddham Epigraphic Archive** (v2019-01-30): 594 objects, 432 inscriptions;
38 Deccan-relevant ones extracted with monarch, date range and dating evidence - 5 inside the box
(Deotek 300-399, Washim 387-397, Yavatmal 430-460, Bidar 445-460), 12 at/just over the edge
(Ajanta, Mandhal, Pauni, Ramtek, Pune). Caveat: the Zenodo record has NO licence field; used
titles/dates only, attributed, removable on request. **The rest of the 1909 volume**: 170 more
dated statements auto-extracted from every district and division section (28 under 1500), quotes
verbatim but actor/cause/outcome NOT curated. Sheet `history_more_2d.png`.
Stack totals: 15,741 place-timelines + 103 curated events + 170 auto statements + 38 inscriptions
+ 124 relation facts + 209 world sites. Details: `history_deep/RULERS_BUILD.md`.

### Topic 3 implementation result (2026-10-07)

The history stack is wired into the engine, per-place lookup strategy. New `RulerRegister.java`
reads the two-level pack (15,741 places / 274 timelines / 43,698 spans, 5.0 MB) with a 0.5-degree
grid and answers `rulerAt(lat, lon, year)`; `HistoricalPresence.Result` now carries the ruler and
`spawnCivId()` prefers it after an in-world occupant; `CivSynthesis` synthesises the 30 polity ids
and logs the register at boot. Events: 290 rows in `deccan_events.json` (103 curated + 170 auto +
17 located inscriptions), added to `index.json`. Evidence: `typecheck_c.sh` compiles the real
files and runs `RulerPackCheck` - 16/16 pass; `validate_engine_events.py` - 290/290 load.
Only Gradle can prove the mod itself; the stubs approximate Forge.
